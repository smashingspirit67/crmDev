({
	doInit : function(component, event, helper) {
		helper.aggregatehelper(component,event);
	}
})