({
    aggregatehelper : function(component,event) {
        var actionVar =component.get('c.pageLoad');
        actionVar.setParams({
            "recordId": component.get("v.recordId")
        });
        
        actionVar.setCallback(this, function(response) {
            
            var state=response.getState();
            if (state === 'SUCCESS') {
                var resultMap = response.getReturnValue();
                for(var mapKey in resultMap)
                {
                    if(mapKey == 'true')
                    {   
                        var typeOfMsg;
                        var resultToast = $A.get("e.force:showToast");
                        if(resultMap[mapKey].includes('under process')){
                            typeOfMsg = 'info';
                        }
                        else{
                            typeOfMsg = 'success';
                        }
                        $A.get('e.force:refreshView').fire();
                        
                        resultToast.setParams({
                            "type":typeOfMsg,
                            "message" : resultMap[mapKey]
                        });
                        resultToast.fire();
                        $A.get("e.force:closeQuickAction").fire();
                    }
                      else
                       {
                            var resultErrorToast = $A.get("e.force:showToast");
                            resultErrorToast.setParams({
                                "title":"Error!",
                                "type":"error",
                                "mode": "sticky",
                                "message" : resultMap[mapKey]
                            });
                            resultErrorToast.fire();
                            $A.get("e.force:closeQuickAction").fire();
                        }
                            
                     }
                            
                    }
                      else if(state === "ERROR")      
                      {
                            var resultErrorToast = $A.get("e.force:showToast");
                            resultErrorToast.setParams({
                                "title":"Error!",
                                "type":"error",
                                "mode": "sticky",
                                "message":"Unable to process the request"
                            });
                            resultErrorToast.fire();
                            $A.get("e.force:closeQuickAction").fire();
                       }
                })
           $A.enqueueAction(actionVar);
          }
})