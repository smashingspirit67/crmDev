/*************************************************************************************
* @Summary 		: Client Side controller for the component CB_ActionPlanComponent         
* @Parameters 	: Component
* @Parameters 	: Event
* @Parameters 	: Helper
* @Component 	: CB_ActionPlanComponent   
* @Helper 		: CB_ActionPlanComponentHelper 
* @Apex class 	: CB_ActionPlanController        
***************************************************************************************/        

({
 	
    /********************************************************************************************************************
         * @Summary         : Method to initialize values and load the component
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_ActionPlanComponent  
         * @Helper Method   : getDefaultValues, getYearValues, getActionPlan, getRelationshipRecord, modalWindowAttributes
         * @Apex class      : CB_ActionPlanController      
     ********************************************************************************************************************/     
    
    doInit: function(component, event, helper) {
        // call the helper methods on component load
        helper.getDefaultValues(component, event);
        helper.getYearValues(component, event);
        helper.getActionPlan(component, event);
        helper.getRelationshipRecord(component, event);
        helper.modalWindowAttributes(component, event);
        helper.checkAccessOfUser(component, event);
    },
    
    /********************************************************************************************************************
         * @Summary         : calling the helper method to handle create operartion
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_ActionPlanComponent  
         * @Helper Method   : handleCreateRecord
         * @Apex class      : CB_ActionPlanController        
     ********************************************************************************************************************/     
    
    handleCreateRecord: function(component, event, helper) {
        helper.handleCreateRecord(component, event);
    },
    
    /********************************************************************************************************************
         * @Summary         : calling the helper method to reload/refresh the table on change of the selected year
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_ActionPlanComponent  
         * @Helper Method   : fetchRecordOfSelectedYear
         * @Apex class      : CB_ActionPlanController        
     ********************************************************************************************************************/     
    
    fetchRecordOfSelectedYear: function(component, event, helper) {
        // call the helper method
        helper.fetchRecordOfSelectedYear(component, event);
    },
    
    /********************************************************************************************************************
         * @Summary         : calling the helper method to save the edited Action Plan record
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_ActionPlanComponent  
         * @Helper Method   : saveRecords
         * @Apex class      : CB_ActionPlanController        
     ********************************************************************************************************************/     
    
    saveRecords: function(component, event, helper) {
        helper.saveRecordsHelper(component, event);
    },
    
   //This section is under progress, will comment after functionality achived.
    printSection: function (component, event, helper) {
        var printContents = document.getElementById('table123').innerHTML;
        var originalContents = document.body.innerHTML;

        var newWin = window.open("");
        newWin.document.write(printContents);
    },

    //This section Will set the date and time with respect to the component.
    doneRendering: function(component, event, helper) {
        var objToday = new Date(component.get('v.ActionPlan.LastModifiedDate'))
            var weekday = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
            dayOfWeek = weekday[objToday.getDay()],
            domEnder = function () { var a = objToday; if (/1/.test(parseInt((a + "").charAt(0)))) return "th"; a = parseInt((a + "").charAt(1)); return 1 == a ? "st" : 2 == a ? "nd" : 3 == a ? "rd" : "th" }(),
            dayOfMonth = today + (objToday.getDate() < 10) ? '0' + objToday.getDate() + domEnder : objToday.getDate() + domEnder,
            months = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'),
            curMonth = months[objToday.getMonth()],
            curYear = objToday.getFullYear(),
            curHour = objToday.getHours() > 12 ? objToday.getHours() - 12 : (objToday.getHours() < 10 ? "0" + objToday.getHours() : objToday.getHours()),
            curMinute = objToday.getMinutes() < 10 ? "0" + objToday.getMinutes() : objToday.getMinutes(),
            curMeridiem = objToday.getHours() > 12 ? "PM" : "AM";

        var today = curMonth + " " + dayOfMonth + ", " + curYear + " " + curHour + ":" + curMinute + curMeridiem;
        if (document.getElementById('lastModifiedDate') != null) {
            document.getElementById('lastModifiedDate').innerHTML = today;
        }
    }
})