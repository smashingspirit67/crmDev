/*************************************************************************************
* @Summary      : Client Side helper for the component CB_ActionPlanComponent         
* @Parameters   : Component
* @Parameters   : Event
* @Parameters   : Helper
* @Component    : CB_ActionPlanComponent   
* @Helper       : CB_ActionPlanComponentHelper 
* @Apex class   : CB_ActionPlanController        
***************************************************************************************/        

({
    /********************************************************************************************************************
         * @Summary 		: Method to set the value for ActionPlan attribute of the component on load of the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_ActionPlanComponent  
         * @Helper Method 	: getActionPlan
         * @Apex class 		: CB_ActionPlanController 
         * @Apex Method 	: getActionPlan        
     ********************************************************************************************************************/     
    
    getActionPlan: function(component, event) {
        
        // calling apex method to fetch child record
        var action = component.get('c.getActionPlan');
        
        //sending parameters to the apex method
        action.setParams({
            "ParentId": component.get("v.recordId"),
            "CurrentYear": true,
            "selectedYear": null
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                //setting response value in ActionPlan attribute on component.
                if(actionResult.getReturnValue()!=null){
                    component.set('v.ActionPlan', actionResult.getReturnValue());
                    component.set("v.inputReadOnly", false);
        			component.set("v.RecordAvailable", true);
                    component.set("v.hideElement", false);
                    component.set("v.disableButton", false);
                    component.set("v.OldRecordAvailable", true)
                }
                else{
                    component.set('v.RecordAvailable',false);
                    component.set('v.OldRecordAvailable',true);
                   	component.set('v.hideElement',true);
                    component.set('v.disableButton',true);
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    
    /********************************************************************************************************************
         * @Summary 		: Method to set the value for options attribute of the component on load of the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_ActionPlanComponent  
         * @Helper Method 	: getYearValues
         * @Apex class 		: N.A 
         * @Apex Method 	: N.A        
     ********************************************************************************************************************/     
    
    getYearValues: function(component, event) {
        //getting the current year value
        var currentYear = (new Date()).getFullYear();
        //getting the previous year value
        var previousYear = currentYear-1;
        var yearAhead = currentYear+1;
        //setting the values for the dropdown menu i.e. options attribute
        var opts = [
            { value: currentYear, label: currentYear },
            { value: previousYear, label: previousYear }
        ];
        component.set("v.CurrentYear", currentYear);
        component.set("v.NextYear", yearAhead);
        component.set("v.options", opts);
    },
    
    /********************************************************************************************************************
         * @Summary 		: Method to set the default value for boolean attributes of the component on load of the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_ActionPlanComponent  
         * @Helper Method 	: getDefaultValues
         * @Apex class 		: N.A 
         * @Apex Method 	: N.A        
     ********************************************************************************************************************/     
    getDefaultValues: function(component, event){
        component.set("v.inputReadOnly", false);
        component.set("v.RecordAvailable", true);
        component.set("v.hideElement", false);
        component.set("v.disableButton", false);
        component.set("v.OldRecordAvailable", true);
        
    },
    
     /********************************************************************************************************************
         * @Summary 		: Method to set the value for ParentRelationship attribute of the component on load of the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_ActionPlanComponent  
         * @Helper Method 	: getRelationshipRecord
         * @Apex class 		: CB_ActionPlanController 
         * @Apex Method 	: getRelationshipRecord        
     ********************************************************************************************************************/     
    getRelationshipRecord: function(component, event){
		var actionRelationship = component.get('c.getAccountRecord');
        
        //sending parameters to the apex method
        actionRelationship.setParams({
            "recId": component.get("v.recordId")
        });
        
        actionRelationship.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                //set response value in ParentRelationship attribute on component.
                component.set("v.ParentRelationship",actionResult.getReturnValue());
            }
        });
        $A.enqueueAction(actionRelationship);        
    },
    
    /********************************************************************************************************************
         * @Summary 		: Method to set the value for ParentRelationship attribute of the component on load of the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_ActionPlanComponent  
         * @Helper Method 	: checkAccessOfUser
         * @Apex class 		: CB_ActionPlanController 
         * @Apex Method 	: getAccessOfLoggedInUser        
     ********************************************************************************************************************/     
   
    checkAccessOfUser : function(component, event){
        var action = component.get('c.getAccessOfLoggedInUser');
        //sending parameters to the apex method
        action.setParams({
            "recId" : component.get('v.recordId')
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                var userHasEditAccess = actionResult.getReturnValue();
                if(!userHasEditAccess){
                    component.set('v.inputReadOnly',true);
                    component.set('v.disableButton',true);
                    component.set('v.disableNewButton',true);
                }
            }
        });
        $A.enqueueAction(action); 
    },
    
    /********************************************************************************************************************
         * @Summary         : Method to set the value for modal window attribute of the component on load of the component      
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_ActionPlanComponent  
         * @Helper Method   : modalWindowAttributes
         * @Apex class      : CB_ActionPlanController 
         * @Apex Method     : N.A        
     ********************************************************************************************************************/     
     modalWindowAttributes: function(component, event){
        component.find("actionPlanRecordCreator").getNewRecord(
            "CB_ActionPlan__c", // sObject type (objectApiName)
            null,      // recordTypeId
            false,     // skip cache?
            $A.getCallback(function() {
                var rec = component.get("v.newActionPlan");
                var error = component.get("v.newActionPlanError");
                if(error || (rec === null)) {
                    console.log("Error initializing record template: " + error);
                    return;
                }
                console.log("Record template initialized: " + rec.sobjectType);
            })
        );
    },
    
     /********************************************************************************************************************
         * @Summary 		: Method to create a new Action Plan record      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_ActionPlanComponent  
         * @Helper Method 	: handleCreateRecord
         * @Apex class 		: CB_ActionPlanController 
         * @Apex Method 	: getRelationshipRecord        
     ********************************************************************************************************************/     
     handleCreateRecord: function(component, event) {
         var relationship = component.get("v.ParentRelationship").Id;
         
         
         component.set("v.simpleNewActionPlan.CB_RelatedAccount__c", relationship);
            component.find("actionPlanRecordCreator").saveRecord(function(saveResult) {
                if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") {
                    // record is saved successfully
                    var resultsToast = $A.get("e.force:showToast");
                    resultsToast.setParams({
                        "title": "Saved",
                        "message": "A New Action Plan is created."
                    });
                    resultsToast.fire();

                } else if (saveResult.state === "INCOMPLETE") {
                    // handle the incomplete state
                    console.log("User is offline, device doesn't support drafts.");
                } else if (saveResult.state === "ERROR") {
                    var msg = JSON.stringify(saveResult.error);
                    if(msg.includes("insufficient")){
                        msg = "You don't have sufficient privileges to edit this record"
                    }
                    var resultsToast = $A.get("e.force:showToast");    
                    resultsToast.setParams({
                        "type": "error",
                        "title": "ERROR",
                        "mode": "sticky",
                        "message": msg
                    });
                    resultsToast.fire();
                    // handle the error state
                    console.log('Problem saving contact, error: ' + JSON.stringify(saveResult.error));
                } else {
                    console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
                }
            });
         
        
    },
    /********************************************************************************************************************
         * @Summary 		: Method to rerender the table on change of the selected year from the drop down menu on the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_ActionPlanComponent  
         * @Helper Method 	: fetchRecordOfSelectedYear
         * @Apex class 		: CB_ActionPlanController
         * @Apex Method 	: getActionPlan,getActionConfig       
     ********************************************************************************************************************/     
    fetchRecordOfSelectedYear: function(component, event) {
        
        //getting the selected value from the drop down menu of the component
        var yearValue = event.getSource().get("v.value");
        
        //getting the current year
        var currentYearOfToday = (new Date()).getFullYear();
        
        //setting of attributes depending upon the selected year
        if(yearValue>=currentYearOfToday){
            component.set('v.inputReadOnly',false);
            component.set('v.disableButton',false);
        }
        else{
            component.set('v.inputReadOnly',true);
            component.set('v.disableButton',true);
        }
        
        // calling apex method to fetch Action Plan Record
        var action = component.get('c.getActionPlan');
        
        //sending parameters to the apex method getActionPlan
        action.setParams({
            "ParentId": component.get("v.recordId"),
            "selectedYear": yearValue,
            "CurrentYear": false
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                //setting response value in ActionPlan attribute and boolean attributes on component 
                //depending upon some condition
                if(actionResult.getReturnValue()!=null){
                    component.set('v.ActionPlan', actionResult.getReturnValue());
                    component.set('v.hideElement',false);
                    component.set('v.RecordAvailable',true);
                    component.set('v.OldRecordAvailable',true);
                }
                else{
                    component.set('v.hideElement',true);
                    component.set('v.disableButton',true);
                    if(yearValue<currentYearOfToday){
                        component.set('v.RecordAvailable',true);
                        component.set('v.OldRecordAvailable',false);
                    }
                    else{
                        component.set('v.RecordAvailable',false);
                        component.set('v.OldRecordAvailable',true);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    /********************************************************************************************************************
         * @Summary 		: Method to save the Action Plan record after editing and refreshing the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_ActionPlanComponent  
         * @Helper Method 	: saveRecordsHelper
         * @Apex class 		: CB_ActionPlanController
         * @Apex Method 	:        
     ********************************************************************************************************************/     
    saveRecordsHelper: function(component, event) {
        var action = component.get('c.updateActionPlan');
        var actionPlan = component.get("v.ActionPlan");
        action.setParams({
            "actionPlanRecord":actionPlan
            
        });
        action.setCallback(this, function(actionResult) {

            if(actionResult.getReturnValue()==null){
            
                var resultsToast = $A.get("e.force:showToast");
                    resultsToast.setParams({
                        "type": "success",
                        "title": "Saved",
                        "message": "The record was saved."
                    });
                    resultsToast.fire();
            }
            else{
                var resultsToast = $A.get("e.force:showToast");
                var msg = actionResult.getReturnValue();
                if(msg.includes("insufficient")){
                    msg = "You don't have sufficient privileges to edit this record"
                }
                    resultsToast.setParams({
                        "type": "error",
                        "title": "ERROR",
                        "message": msg
                    });
                    resultsToast.fire();
            }
        }
                          );
        $A.enqueueAction(action);
    }
        
 })