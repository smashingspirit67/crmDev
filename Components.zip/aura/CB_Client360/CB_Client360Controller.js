({
	doInit: function(component, event, helper) {
		component.set('{!v.counter360}', false);
	},

	onRender : function(component, event, helper) {
		if (!component.get('{!v.counter360}')) {
			var userId = '';
			userId = component.get("v.recordId");
            if(userId!=null){
                helper.getcashMgmtRecords(component, event, helper, userId, '{!c.setAttributesCashMgmt}', '{!v.cashMgmtDetails}', '{!v.cashMgmtDetailsMap}');
                helper.getTableRecords(component, event, helper, userId, '{!c.setAttributesDeposit}', '{!v.depositDetails}', 'CB_Interest_Amount__c', 'CB_As_Of_Date__c', '{!v.graphValue2}', '{!v.depositDate}', '{!v.truthy3}', '{!v.depositMap}', '{!v.depositMapSize}');
                helper.getTableRecords(component, event, helper, userId, '{!c.setAttributesLoan}', '{!v.loanDetails}', 'CB_Interest_Amount__c', 'CCMIS_As_Of_Date__c', '{!v.graphValue7}', '{!v.loanDate}', '{!v.truthy2}', '{!v.loanMap}', '{!v.loanMapSize}');
                helper.getTableRecords(component, event, helper, userId, '{!c.setAttributesStucky}', '{!v.stuckyDetails}', 'CB_Avail__c', 'CB_As_Of_Date__c', '{!v.graphValue4}', '{!v.stuckyDate}', '{!v.truthy4}', '{!v.stuckyMap}', '{!v.stuckyMapSize}');
                helper.getTableRecords(component, event, helper, userId, '{!c.setAttributesOther}', '{!v.otherDetails}', 'CB_Current_Month_Fees__c', 'CB_Month_End_Date__c', '{!v.graphValue5}', '{!v.otherDate}', '{!v.truthy5}', '{!v.otherMap}', '{!v.otherMapSize}');
                helper.getTableRecords(component, event, helper, userId, '{!c.setAttributesCards}', '{!v.cardsDetails}', 'CB_Current_Balance__c', 'CB_Month_End_Date__c', '{!v.graphValue3}', '{!v.cardsDate}', '{!v.truthy6}', '{!v.cardsMap}', '{!v.cardsMapSize}');
                helper.getTableRecords(component, event, helper, userId, '{!c.setAttributesClosed}', '{!v.closedDetails}', 'CB_Interest_Amount__c', 'CB_As_Of_Date__c', '{!v.graphValue6}', '{!v.closedDate}', '{!v.truthy7}', '{!v.closedMap}', '{!v.closedMapSize}');
			}
            
			function sumHelper(component, event, helper) {
				helper.sumTopCards(component, event, helper);
			}

			setTimeout(sumHelper.bind(null, component, event, helper), 3000);

			console.log('Ran ' + component.get('{!v.counter360}'));
			component.set('{!v.counter360}', true);
			console.log('Ran ' + component.get('{!v.counter360}'));
		}
	},

	navToRecord : function(component, event, helper) {
		var url = event.currentTarget.id;
		var navEvt = $A.get("e.force:navigateToSObject");
		navEvt.setParams({
			"recordId": url
		});
		navEvt.fire();
	},

	toggleAccordion : function(component, event, helper) {
		// var targetId = event.currentTarget.id.split(';')[0];
		var targetIndex = event.currentTarget.id;
		var icon = component.find('chevron');
		if (icon.length) {
			if (icon[targetIndex].get('v.iconName') == 'utility:chevronright') {
				icon[targetIndex].set('v.iconName', 'utility:chevrondown');
			} else {
				icon[targetIndex].set('v.iconName', 'utility:chevronright');
			}
		} else {
			if (icon.get('v.iconName') == 'utility:chevronright') {
				icon.set('v.iconName', 'utility:chevrondown');
			} else {
				icon.set('v.iconName', 'utility:chevronright');
			}
		}
		$A.util.toggleClass(document.getElementById(targetIndex + ';sub'), 'slds-hide');
		console.log('Toggled');
	},

	display: function (component, event, helper) {
		helper.toggleHelper(component, event);
	},

	displayOut: function (component, event, helper) {
		helper.toggleHelper(component, event);
	}
})