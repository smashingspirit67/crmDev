({
	drawGraphs : function(component, event, helper) {
		var pieCharts = document.querySelectorAll('.pie-chart');

		Array.prototype.forEach.call(pieCharts, function (wrapperEl) {
			// Pull our variables out of our helper div
			var dataset = wrapperEl.dataset;
			var percentage = dataset.percentage ? parseInt(dataset.percentage, 10) : 0;
			var diameter = dataset.diameter ? parseInt(dataset.diameter, 10) : 150;
			var strokeWidth = dataset.strokeWidth ? parseInt(dataset.strokeWidth, 10) : 15;
			var fillColor = dataset.fillColor || '#EC0000'; // orange
			var bgColor = dataset.bgColor || '#ff8080'; // light orange

			// Size our wrapper element and add our percentage
			wrapperEl.style.height = diameter + 'px';
			wrapperEl.style.width = diameter + 'px';
			var percentageEl = document.createElement('span');
			percentageEl.classList.add('pie-chart__percentage');
			percentageEl.style.color = fillColor;
			percentageEl.innerText = percentage + '%';
			wrapperEl.appendChild(percentageEl);

			// Setting up the values we're gonna use to draw our circles
			var center = diameter;
			var radius = center - (strokeWidth);
			var startAngle = degreesToRadians(-90);
			var fullCircle = degreesToRadians(365);
			var endAngle = startAngle + degreesToRadians(percentage / 100 * 365);

			// Draw our canvas! Note we're doubling our sizes so we look good on high res displays
			var canvas = document.createElement('canvas');
			canvas.classList.add('pie-chart__canvas');
			canvas.height = diameter * 2;
			canvas.width = diameter * 2;
			var ctx = canvas.getContext('2d');
			ctx.lineWidth = strokeWidth * 2;
			ctx.strokeStyle = bgColor;
			ctx.beginPath();
			ctx.arc(center, center, radius, startAngle, fullCircle);
			ctx.stroke();
			ctx.strokeStyle = fillColor;
			ctx.beginPath();
			ctx.arc(center, center, radius, startAngle, endAngle);
			ctx.stroke();

			wrapperEl.appendChild(canvas);
		});

		function degreesToRadians(degrees) {
			return (degrees / 360) * (2 * Math.PI);
		}
	},

	getTableRecords: function (component, event, helper, param, controllerClass, attribute, countVariable, asOfVariable, setVariable, dateVariable, displayBool, mapVaribale, mapSize) {
		component.set(displayBool, false);
		var action = component.get(controllerClass);
		action.setParams(
			{
				"param": param
			}
		);

		action.setCallback(this, function (response) {
			var arr = [];
			var arr1 = [];
			var arr2 = [];
			var keys = [];
			
			var state = response.getState();
			if (state === 'SUCCESS') {
				component.set(attribute, response.getReturnValue());
				console.log(response);
				if (response.getReturnValue().length > 0) {
					var keyArr = [];
					for (var m = 0; m < response.getReturnValue().length; m++) {
						keyArr.push(Object.keys(response.getReturnValue()[m]).sort());
					}
					
					for (var n = 0; n < keyArr.length; n++) {
						keyArr[n] = keyArr[n].length;
					}
					
					var maxIndex = keyArr.reduce((iMax, x, i, arr) => x > arr[iMax] ? i : iMax, 0);
					keys = Object.keys(response.getReturnValue()[maxIndex]).sort();

					for (var k = 0; k < keys.length; k++) {
						var newArr = [];
						arr2.push(newArr);
					}
				}

				var maps = component.get(mapVaribale);

				

				for (var i = 0; i < response.getReturnValue().length; i++) {
					if (response.getReturnValue()[i][countVariable] != null) {
						arr.push(response.getReturnValue()[i][countVariable]);
					}

					if (response.getReturnValue()[i][asOfVariable] != null) {
						arr1.push(response.getReturnValue()[i][asOfVariable]);
					}
					
					if (response.getReturnValue().length > 0) {
						for (var l = 0; l < keys.length; l++) {
							arr2[l].push(response.getReturnValue()[i][keys[l]]);
						}
					}
				}

				if (response.getReturnValue().length > 0) {
					for (var j = 0; j < keys.length; j++) {
						maps[keys[j]] = j;
					}
					helper.arrSum(component, helper, arr2, keys, maps, mapVaribale, mapSize);
				}

			}
			else {
				console.log(state);
			}
			// helper.arrSum(component, attribute, arr, setVariable);
			helper.dateCalc(component, attribute, arr1, dateVariable, displayBool);
		});
		$A.enqueueAction(action);
	},

	getcashMgmtRecords: function (component, event, helper, param, controllerClass, keysList, keysMap) {
		var action = component.get(controllerClass);
        action.setParams(
			{ 
				"param" : param 
			}
		);

        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
				var arr = [];
				var arr2 = [];
				var dateArray = [];
				var keysArray = [];
				var keys = Object.keys(response.getReturnValue());

					// component.set(keysList, keys);
					component.set(keysMap, response.getReturnValue());
					for (var i = 0; i < keys.length; i++) {
						var arr1 = [];
						var prod200Map = response.getReturnValue()[keys[i]];
						arr1['key']= keys[i];
						arr1['map'] = prod200Map;
						
						var prodKeys = [];

						for (var v = 0; v < response.getReturnValue()[keys[i]].length; v++) {
							dateArray.push(response.getReturnValue()[keys[i]][v]['CB_Month_End_Date__c']);
						}

						for (var j = 0; j < prod200Map.length; j++) {
							prodKeys.push(Object.keys(prod200Map));
						}

						for (var n = 0; n < prodKeys.length; n++) {
							prodKeys[n] = prodKeys[n].length;
						}

						var maxIndex = prodKeys.reduce((iMax, x, i, arr) => x > arr[iMax] ? i : iMax, 0);
						prodKeys = Object.keys(prod200Map[maxIndex]);
						
						var newArr = new Map();

						for (var a = 0; a < prod200Map.length; a++) {
							for (var b = 0; b < prodKeys.length; b++) {
								if (newArr[prodKeys[b]] != null ) {
									newArr[prodKeys[b]] = newArr[prodKeys[b]] + parseFloat(prod200Map[a][prodKeys[b]]);
								} else {
									newArr[prodKeys[b]] = parseFloat(prod200Map[a][prodKeys[b]]);
								}
							}
						}
                        console.log('newArr',newArr);
						for (var c = 0; c < prodKeys.length; c++) {
							arr1[prodKeys[c]] = newArr[prodKeys[c]];
						}
                        console.log('arr1',arr1);
						arr.push(arr1);
                        console.log('arr1',arr1);					}
					helper.dateCalc(component, null, dateArray, '{!v.cashMgmtDate}', '{!v.truthy1}');
					component.set(keysList, arr);
					helper.arrSumCashMgmt(component, arr, prodKeys);
            }
            else if (state === "INCOMPLETE") {
                // do something
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
			}
		});
		$A.enqueueAction(action);
	},

	arrSum: function (component, helper, arr2, keys, maps, mapVaribale, mapSize) {
		for (var i = 0; i < arr2.length; i++) {
			var newArr1 = [];
			for (var j = 0; j < arr2[i].length; j++) {
				if (helper.numChecker(component, helper, arr2[i][j])) {
                    console.log(arr2[i][j]);
					newArr1.push(parseFloat(arr2[i][j]));
				}
			}
            console.log(newArr1);
			arr2[i] = newArr1;

			if (arr2[i]!=null && arr2[i]!='' && !arr2[i].some(isNaN)) {
				arr2[i] = arr2[i].reduce((a, b) => a + b, 0);
			}
		}

		for (var l = 0; l < keys.length; l++) {
			maps[keys[l]] = arr2[l];
		}
		component.set(mapVaribale, maps);
		component.set(mapSize, keys.length);
	},

	numChecker: function (component, helper, number) {
		return number != null && number != '' && !isNaN(parseFloat(number)) && isFinite(number);
	},

	arrSumCashMgmt: function (component, arr, keyList) {
		var keyMap = new Map();

		for (var i = 0; i < arr.length; i++) {
			for (var j = 0; j < keyList.length; j++) {
				if (keyMap[keyList[j]] != null) {
					keyMap[keyList[j]] = keyMap[keyList[j]] + parseFloat(arr[i][keyList[j]]);
				} else {
					keyMap[keyList[j]] = parseFloat(arr[i][keyList[j]]);
				}
			}
		}
		component.set('{!v.cashMgmtMap}', keyMap);
	}, 

	dateCalc: function (component, attribute, arr1, dateVariable, displayBool) {
		var orderedDates = arr1.sort(function (a, b) {
			return Date.parse(a) > Date.parse(b);
		});
		if (arr1.length > 0) {
			component.set(displayBool, true);
			component.set(dateVariable, orderedDates[orderedDates.length - 1]);
		}
	},

	sumTopCards: function(component, event, helper) {
		var cardsRevYTD = component.get('{!v.cardsMap.CB_Transaction_Revenue_YTD__c}');
		var otherYTDFees = component.get('{!v.otherMap.CB_YTD_Fees__c}');
		var loanNII = component.get('{!v.loanMap.CB_Net_Interest_Income_YTD__c}');
		var loanFees = component.get('{!v.loanMap.CB_Total_Loan_Fees_YTD__c}');
		var depositsNII = component.get('{!v.depositMap.CB_Net_Interest_Income_YTD__c}');
		var cashMgmtFees = component.get('{!v.cashMgmtMap.CB_Fees_Due_YTD__c}');
		var loanExposure = component.get('{!v.loanMap.CCMIS_Exposure_Amount__c}');
		var depositBalance = component.get('{!v.depositMap.CB_Month_End_Balance__c}');
		var cashMgmtPxV = component.get('{!v.cashMgmtMap.CB_PxV_YTD__c}');

		cardsRevYTD = helper.nAnChecker(component, event, helper, cardsRevYTD);
		otherYTDFees = helper.nAnChecker(component, event, helper, otherYTDFees);
		loanNII = helper.nAnChecker(component, event, helper, loanNII);
		loanFees = helper.nAnChecker(component, event, helper, loanFees);
		depositsNII = helper.nAnChecker(component, event, helper, depositsNII);
		cashMgmtFees = helper.nAnChecker(component, event, helper, cashMgmtFees);
		loanExposure = helper.nAnChecker(component, event, helper, loanExposure);
		depositBalance = helper.nAnChecker(component, event, helper, depositBalance);
		cashMgmtPxV = helper.nAnChecker(component, event, helper, cashMgmtPxV);

		var card4 = [];
		var card5 = [];

		card4.push(cardsRevYTD, otherYTDFees);
		card5.push(loanNII, loanFees, depositsNII, cashMgmtFees, cardsRevYTD, otherYTDFees);

		function isComplete (array) {
			var newArr = [];
			for (var i = 0; i < array.length; i++) {
				if (array[i] != null && array[i] != '' && !isNaN(array[i])) {
					newArr.push(array[i]);
				}
			}
			return newArr;
		}

		var actualCard4 = isComplete(card4);
		var actualCard5= isComplete(card5);
		
		actualCard4 = actualCard4.reduce((a, b) => a + b, 0);
		actualCard5 = actualCard5.reduce((a, b) => a + b, 0);

		loanExposure = '$' + Math.round(loanExposure/1000000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' MM';
		depositBalance = '$' + Math.round(depositBalance/1000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' M';
		cashMgmtPxV = '$' + Math.round(cashMgmtPxV/1000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' M';
		actualCard4 = '$' + Math.round(actualCard4/1000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' M';
		actualCard5 = '$' + Math.round(actualCard5 / 1000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' M';
		
		component.set('{!v.graphValue1}', loanExposure);
		component.set('{!v.graphValue2}', depositBalance);
		component.set('{!v.graphValue3}', cashMgmtPxV);
		component.set('{!v.graphValue4}', actualCard4);
		component.set('{!v.graphValue5}', actualCard5);
	}, 

	nAnChecker: function(component, event, helper, number) {
		if (!isNaN(number) && number!=null && number != '' && number != undefined) {
			return number;
		} else {
			return 0;
		}
	},

	toggleHelper: function (component, event) {
		var toggleText = component.find("tooltip");
		$A.util.toggleClass(toggleText, "slds-hide");
	}
})