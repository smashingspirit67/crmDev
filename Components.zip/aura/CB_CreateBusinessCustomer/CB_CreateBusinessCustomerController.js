/*************************************************************************************
* @Summary      : Client Side controller for the component CB_CreateBusinessCustomer         
* @Parameters   : Component
* @Parameters   : Event
* @Parameters   : Helper
* @Component    : CB_CreateBusinessCustomer   
* @Helper       : CB_CreateBusinessCustomerHelper.Js 
* @Apex class   : CB_CreateBusinessCustomerController        
***************************************************************************************/      
({

/********************************************************************************************************************
         * @Summary         : Method to initialize values and load the component
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateBusinessCustomer  
         * @Helper Method   : checkErrorMatrix, getRelationship, getLookupValues, getValuesForDependentPicklist
         * @Apex class      : CB_CreateBusinessCustomerController      
********************************************************************************************************************/     
    
	doInit : function(component, event, helper) {
        
        //helper.checkErrorMatrix(component, event);
        helper.getRelationship(component, event);
        helper.getLookupValues(component, event);
        helper.getValuesForDependentPicklist(component, event);
        helper.getLoggedInUserForOwner(component, event);
    },

/********************************************************************************************************************
         * @Summary         : Method to handle the component event to set the values for the picklist value attributes
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateBusinessCustomer  
         * @Helper Method   : N.A
         * @Apex class      : CB_CreateBusinessCustomerController      
********************************************************************************************************************/     

    handleMyPicklistComponentEvent : function(component, event, helper) {
        
        var cmpName = event.getParam("masterFieldApiName");
        if(cmpName == 'BDP_Entity_Type__c'){
            var valueOfControllingField1 = event.getParam("controllingFieldValue");
            var valueOfDependentField1 = event.getParam("dependentFieldValue");
            component.set("v.EntityType",valueOfControllingField1);
            component.set("v.AdditionalDetails",valueOfDependentField1);
        }
        else if(cmpName == 'BDP_Country_of_Organization__c'){
            var valueOfControllingField2 = event.getParam("controllingFieldValue");
            var valueOfDependentField2 = event.getParam("dependentFieldValue");
            component.set("v.CountryOfOrg",valueOfControllingField2);
            component.set("v.StateOfIncorporation",valueOfDependentField2);
        }
    },

	/********************************************************************************************************************
         * @Summary         : Action to be executed if cancel is clicked in edit mode
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateBusinessCustomer  
         * @Helper Method   : N.A
         * @Apex class      : CB_CreateBusinessCustomerController      
********************************************************************************************************************/     

    closeModal : function(component,event,helper){  
        //checking if it is a create request or convert request
        var record = component.get("v.recordId");
        if(record != null){
            $A.get("e.force:closeQuickAction").fire();
        }
        else{
        // call the event   
        var compEvent = component.getEvent("communicate");
        // set the Selected sObject Record to the event attribute.  
        compEvent.setParams({"openModalWindow" : false });  
        // fire the event  
        compEvent.fire();
        }
    },
/********************************************************************************************************************
         * @Summary         : Action to close the error notification
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateBusinessCustomer  
         * @Helper Method   : NA
         * @Apex class      : CB_CreateBusinessCustomerController      
********************************************************************************************************************/     

    closeErrorPill : function(component,event,helper){  
        //checking if it is a create request or convert request
        component.set('v.errorMessage',null);
    },
/********************************************************************************************************************
         * @Summary         : Action to enable or disable mailing address fields
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateBusinessCustomer  
         * @Helper Method   : enableDisableMailingAddressFields
         * @Apex class      : CB_CreateBusinessCustomerController      
********************************************************************************************************************/     

    enableDisableMailingAddress : function(component, event, helper){
        helper.enableDisableMailingAddressFields(component, event);
    },
 /********************************************************************************************************************
         * @Summary         : Action to be executed if save is clicked in edit mode
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateBusinessCustomer  
         * @Helper Method   : saveRecordHelper
         * @Apex class      : CB_CreateBusinessCustomerController      
********************************************************************************************************************/     
 
    saveRecord : function(component, event, helper) {
        helper.saveRecordHelper(component, event);
    },
    //Under development
    /*checkMandatoryFilled : function(component, event, helper){
        
        if(component)
        // create a empty array var for storing the labels for fields that are required  
        var dependentFields = [];
        if(component.find(entityName).get('v.value') == null){
            dependentFields.push({'Entity Name'});
        }
        if(component.find(letterSalutation).get('v.value') == null){
            dependentFields.push({'Letter Salutation'});
        }
        if(component.find(TinSsnEinPick).get('v.value') == null){
            dependentFields.push({'TIN / SSN / EIN'});
        }
        if(component.find(PhoneDescriptionPick).get('v.value') == null){
            dependentFields.push({'Phone Description'});
        }
        if(component.find(tinSsnEinNum).get('v.value') == null){
            dependentFields.push({'TIN / SSN / EIN #'});
        }
        if(component.find(PhoneTypePick).get('v.value') == null){
            dependentFields.push({'Phone Type'});
        }
        if(component.find(PhoneCountryPick).get('v.value') == null){
            dependentFields.push({'Phone Country'});
        }
        if(component.find(BDPphone).get('v.value') == null){
            dependentFields.push({'Phone'});
        }
        if(component.find(ResidentTaxStatusPick).get('v.value') == null){
            dependentFields.push({'Resident Tax Status'});
        }
        dependentFields.push({''});
        event.getSource().get("v.value");
        
    }*/
    
/********************************************************************************************************************
         * @Summary         : Actions to be executed on changing the selection in picklist fields
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateBusinessCustomer  
         * @Helper Method   : N.A
         * @Apex class      : CB_CreateBusinessCustomerController      
********************************************************************************************************************/     

    
    onSelectChangeCustomerStrategy : function(component, event, helper) {
        var selected = component.find("custStrategy").get("v.value");
        component.set("v.relationship.CB_CustomerStrategy__c", selected);
    },

    onSelectChangeIndustry : function(component, event, helper) {
        var selected = component.find("industryPick").get("v.value");
        component.set("v.relationship.Industry", selected);
    },

    onSelectChangeSalesVolumeRange : function(component, event, helper) {
        var selected = component.find("salesVolumeRangePick").get("v.value");
        component.set("v.relationship.CB_SalesVolumeRange__c", selected);
    },

    onSelectChangeSBNACreditRelationship : function(component, event, helper) {
        var selected = component.find("SBNACreditRelationshipPick").get("v.value");
        component.set("v.relationship.CB_SBNA_Participation__c", selected);
    },

    onSelectChangeSBNACashManagementRelationship : function(component, event, helper) {
        var selected = component.find("SBNACashManagementRelationshipPick").get("v.value");
        component.set("v.relationship.CB_SBNA_CashManagementRelationship__c", selected);
    },

    onChangeMarketingOptOut : function(component, event, helper) {
        var selected = component.find("marketingOptOut").get("v.value");
        component.set("v.relationship.BDP_HasOptedOutOfEmail__c", selected);
    },

    onChangeLevel : function(component, event, helper) {
        var selected = component.find("levelPick").get("v.value");
        component.set("v.relationship.CB_Level__c", selected);
    },

    onChangeMoodysRating : function(component, event, helper) {
        var selected = component.find("moodysRatingPick").get("v.value");
        component.set("v.relationship.CB_Moody_s_Rating__c", selected);
    },

    onChangeFitchRating : function(component, event, helper) {
        var selected = component.find("fitchRatingPick").get("v.value");
        component.set("v.relationship.CB_Fitch_Rating__c", selected);
    },

    onChangeSandPRating : function(component, event, helper) {
        var selected = component.find("SandPRatingPick").get("v.value");
        component.set("v.relationship.CB_S_P_Rating__c", selected);
    },

    onChangeBillingStreet : function(component, event, helper) {
        var selected = component.find("BillingStreetPick").get("v.value");
        component.set("v.relationship.BDP_Street_Address_Format__c", selected);
        
        var billingState = component.get("v.relationship.BDP_Street_Address_State__c");
        var billingUnitType = component.get("v.relationship.BDP_Street_Address_Unit_Type__c");
        
        if(selected == 'Street Type Address (Standard)'){
            component.set("v.IsForeign",false);
            component.find("BillingStatePick").set("v.value",billingState);
            component.find("billingZipCode").set("v.value",component.get("v.onLoadZipCode"));
            component.find("billingZipCode4").set("v.value",component.get("v.onLoadZipCode4"));
            component.find("BillingUnitTypePick").set("v.value",billingUnitType);
            component.find("billingUnitNumber").set("v.value",component.get("v.onLoadUnitNumber"));
            component.find("billingPostalCode").set("v.value",null);
        }
        if(selected == 'Foreign Address'){
            component.set("v.IsForeign",true);
            component.find("BillingStatePick").set("v.value",null);
            component.find("billingZipCode").set("v.value",null);
            component.find("billingZipCode4").set("v.value",null);
            component.find("BillingUnitTypePick").set("v.value",null);
			component.find("billingUnitNumber").set("v.value",null);
            component.find("billingPostalCode").set("v.value",component.get("v.onLoadForeignPostalCode"));
        }
    },

    onChangeMailingStreet : function(component, event, helper) {
        var selected = component.find("MailingStreetPick").get("v.value");
        component.set("v.relationship.BDP_Mailing_Address_Format__c", selected);
        
        var mailingState = component.get("v.relationship.BDP_Street_Address_State__c");
        var mailingUnitType = component.get("v.relationship.BDP_Street_Address_Unit_Type__c");
        
        if(selected == 'Street Type Address (Standard)'){
            component.set("v.IsMailingForeign",false);
            component.find("MailingStatePick").set("v.value",mailingState);
            component.find("mailingZipCode").set("v.value",component.get("v.onLoadmailingZipCode"));
            component.find("mailingZipCode4").set("v.value",component.get("v.onLoadmailingZipCode4"));
            component.find("MailingUnitTypePick").set("v.value",mailingUnitType);
            component.find("mailingUnitNumber").set("v.value",component.get("v.onLoadmailingUnitNumber"));
            component.find("mailingPostalCode").set("v.value",null);
        }
        if(selected == 'Foreign Address'){
            component.set("v.IsMailingForeign",true);
            component.find("MailingStatePick").set("v.value",null);
            component.find("mailingZipCode").set("v.value",null);
            component.find("mailingZipCode4").set("v.value",null);
            component.find("MailingUnitTypePick").set("v.value",null);
			component.find("mailingUnitNumber").set("v.value",null);
            component.find("mailingPostalCode").set("v.value",component.get("v.onLoadmailingForeignPostalCode"));
        }
    },

    onChangeBillingUnitType : function(component, event, helper) {
        var selected = component.find("BillingUnitTypePick").get("v.value");
        component.set("v.relationship.BDP_Street_Address_Unit_Type__c", selected);
    },

    onChangeMailingUnitType : function(component, event, helper) {
        var selected = component.find("MailingUnitTypePick").get("v.value");
        component.set("v.relationship.BDP_Mailing_Address_Unit_Type__c", selected);
    },

    onChangeBillingState : function(component, event, helper) {
        var selected = component.find("BillingStatePick").get("v.value");
        component.set("v.relationship.BDP_Street_Address_State__c", selected);
        if(component.get("v.MailingAddressReadOnly")){
            component.set("v.relationship.BDP_Mailing_Address_State__c", selected);
        }
    },

    onChangeMailingState : function(component, event, helper) {
        var selected = component.find("MailingStatePick").get("v.value");
        component.set("v.relationship.BDP_Mailing_Address_State__c", selected);
    },

    onChangePhoneType : function(component, event, helper) {
        var selected = component.find("PhoneTypePick").get("v.value");
        component.set("v.relationship.BDP_Type__c", selected);
    },

    onChangePhoneCountry : function(component, event, helper) {
        var selected = component.find("PhoneCountryPick").get("v.value");
        component.set("v.relationship.PhoneCountry__c", selected);
    },

    onChangePhoneDescription : function(component, event, helper) {
        var selected = component.find("PhoneDescriptionPick").get("v.value");
        component.set("v.relationship.BDP_Description__c", selected);
    },

    onChangePermanentResidentCountry : function(component, event, helper) {
        var selected = component.find("PermanentResidentCountryPick").get("v.value");
        component.set("v.relationship.Permanent_Resident_Country__c", selected);
    },

    onChangeResidentTaxStatus : function(component, event, helper) {
        var selected = component.find("ResidentTaxStatusPick").get("v.value");
        component.set("v.relationship.BDP_Resident_Status__c", selected);
    },

    onChangeTinSsnEin : function(component, event, helper) {
        var selected = component.find("TinSsnEinPick").get("v.value");
        component.set("v.relationship.BDP_ID_Doc_Type__c", selected);
    },

    onSelectChangeEddApproval : function(component, event, helper) {
        var selected = component.find("eddApprovalPick").get("v.value");
        component.set("v.relationship.EDD_Approval__c", selected);
    },

    onSelectChangeInternetGambling : function(component, event, helper) {
        var selected = component.find("engInInternetGambling").get("v.value");
        component.set("v.relationship.Engaged_in_Internet_Gambling__c", selected);
    },

    onChangeEntityVerificationMethod : function(component, event, helper) {
        var selected = component.find("EntityVerificationMethodPick").get("v.value");
        component.set("v.relationship.Entity_Verification_Method__c", selected);
    },

    onChangeAccountingSector : function(component, event, helper) {
        var selected = component.find("AccountingSectorPick").get("v.value");
        component.set("v.relationship.BDP_Accounting_Sector__c", selected);
    },
    
    onChangeRelationshipToParent : function(component, event, helper) {
        var selected = component.find("RelationshipToParentPick").get("v.value");
        component.set("v.relationship.CB_Relationship_to_the_Parent_Company__c", selected);
    },
    
    onChangeEmployeesRange : function(component, event, helper) {
        var selected = component.find("EmployeesRangePick").get("v.value");
        component.set("v.relationship.CB_Employee_Range__c", selected);
    },
	
    onChangeStrategicPillar : function(component, event, helper) {
        var selected = component.find("strategicPillarId").get("v.value");
        component.set("v.relationship.CB_Strategic_Pillar_Designation__c", selected);
    },
    
    onSelectChangeOwnership : function(component, event, helper) {
        var selected = component.find("OwnershipId").get("v.value");
        component.set("v.relationship.Ownership", selected);
    },
    
    onChangeBid : function(component, event, helper) {
        var selected = component.find("BidPick").get("v.value");
        component.set("v.relationship.CB_Bid__c", selected);
    },
    
    onChangeImpExpIndicator : function(component, event, helper) {
        var selected = component.find("impExpIndicatorPick").get("v.value");
        component.set("v.relationship.CB_Import_Export_Indicator__c", selected);
    },
    
    onChangeImportCountries : function(component, event, helper) {
        var selected = component.find("impCountryPick").get("v.value");
        component.set("v.relationship.CB_IC__c", selected);
    },
    
    onChangeExportCountries : function(component, event, helper) {
        var selected = component.find("expCountryPick").get("v.value");
        component.set("v.relationship.CB_EC__c", selected);
    },
    
    onChangeCountryPresence : function(component, event, helper) {
        var selected = component.find("countryPresencePick").get("v.value");
        component.set("v.relationship.CB_Presence__c", selected);
    },
    
    onChangeInternationalProfile : function(component, event, helper) {
        var selected = component.find("InternationalProfilePick").get("v.value");
        component.set("v.relationship.CB_International_Profile__c", selected);
    },
    
    onChangeTradeProgram : function(component, event, helper) {
        var selected = component.find("TradeProgramPick").get("v.value");
        component.set("v.relationship.CB_Trade_Program__c", selected);
    },
    
    onChangeClientOverseas : function(component, event, helper) {
        var selected = component.find("clientOverseasPick").get("v.value");
        component.set("v.relationship.CB_Client_Overseas__c", selected);
    },
    
    onChangeBillingCountry : function(component, event, helper) {
        var selected = component.find("BillingCountryPick").get("v.value");
        component.set("v.relationship.BDP_Street_Address_Country__c", selected);
        if(component.get("v.MailingAddressReadOnly")){
         	component.set("v.relationship.BDP_Mailing_Address_Country__c", selected);
        }
    },
    
    onChangeMailingCountry : function(component, event, helper) {
        var selected = component.find("MailingCountryPick").get("v.value");
        component.set("v.relationship.BDP_Mailing_Address_Country__c", selected);
    },

    showHelpText : function(component, event, helper) {
        component.set("v.showHelpForCS",true);
    },

    hideHelpText : function(component, event, helper) {
        component.set("v.showHelpForCS",false);
    },

})