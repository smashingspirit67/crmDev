/*************************************************************************************
* @Summary      : Client Side helper for the component CB_CreateBusinessCustomer         
* @Parameters   : Component
* @Parameters   : Event
* @Parameters   : Helper
* @Component    : CB_CreateBusinessCustomer   
* @Helper       : N.A 
* @Apex class   : CB_CreateBusinessCustomerController        
***************************************************************************************/      
({

   /********************************************************************************************************************
         * @Summary         : Method to check the error matrix to ensure the request came from a valid user
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateBusinessCustomer  
         * @Helper Method   : checkErrorMatrix
         * @Apex class      : CB_CreateBusinessCustomerController      
********************************************************************************************************************/ 
checkErrorMatrix : function(component, event) {

        //Checking if request came for creation or conversion
        var record = component.get("v.recordId");
        if(record != null){
        var action = component.get("c.checkErrorMatrix"); 
        
        action.setCallback(this, function(a){ 
       
         var returnMsg = a.getReturnValue();
        
         if(returnMsg != 'Success'){
            var dismissActionPanel = $A.get("e.force:closeQuickAction");
            dismissActionPanel.fire();

            var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "type": "error",
                    "mode": "sticky",
                    "message": returnMsg
                });
            toastEvent.fire();
            
         }   
    });
        $A.enqueueAction(action);
    }

    },

    /********************************************************************************************************************
         * @Summary         : Method to enable or disable mailing address fields
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateBusinessCustomer
         * @Helper Method   : enableDisableMailingAddress
         * @Apex class      : CB_CreateBusinessCustomerController 
         * @Apex Method     : NA        
     ********************************************************************************************************************/     
  
    enableDisableMailingAddressFields : function(component, event) {

        var mailingSameAsBilling = component.find("mailingAddressSame").get("v.value");
        if(mailingSameAsBilling){
            //copying over billing address to mailing address
            component.find("MailingStreetPick").set("v.value",component.get("v.relationship.BDP_Street_Address_Format__c"));
            component.find("mailingStreetNumber").set("v.value",component.find("billingStreetNumber").get("v.value"));
            component.find("mailingStreetName").set("v.value",component.find("billingStreetName").get("v.value"));
            component.find("mailingOptionalLine").set("v.value",component.find("billingOptionalLine").get("v.value"));
            component.find("MailingUnitTypePick").set("v.value",component.find("BillingUnitTypePick").get("v.value"));
            component.find("mailingUnitNumber").set("v.value",component.find("billingUnitNumber").get("v.value"));
            component.find("mailingCity").set("v.value",component.find("billingCity").get("v.value"));
            component.find("MailingStatePick").set("v.value",component.get("v.relationship.BDP_Street_Address_State__c"));
            component.find("mailingZipCode").set("v.value",component.find("billingZipCode").get("v.value"));
            component.find("mailingZipCode4").set("v.value",component.find("billingZipCode4").get("v.value"));
            component.find("mailingValidFromDate").set("v.value",component.find("billingValidFromDate").get("v.value"));
            component.find("MailingCountryPick").set("v.value",component.get("v.relationship.BDP_Street_Address_Country__c"));
            component.find("mailingPostalCode").set("v.value",component.find("billingPostalCode").get("v.value"));
            //disabling the mailing address fields
            component.set("v.MailingAddressReadOnly",true);
        }
        else{
            //copying over billing address to mailing address
            component.find("MailingStreetPick").set("v.value",null);
            component.find("mailingStreetNumber").set("v.value",null);
            component.find("mailingStreetName").set("v.value",null);
            component.find("mailingOptionalLine").set("v.value",null);
            component.find("MailingUnitTypePick").set("v.value",null);
            component.find("mailingUnitNumber").set("v.value",null);
            component.find("mailingCity").set("v.value",null);
            component.find("MailingStatePick").set("v.value",null);
            component.find("mailingZipCode").set("v.value",null);
            component.find("mailingZipCode4").set("v.value",null);
            component.find("mailingValidFromDate").set("v.value",null);
            component.find("MailingCountryPick").set("v.value",null);
            component.find("mailingPostalCode").set("v.value",null);
            //enabling the mailing address fields
            component.set("v.MailingAddressReadOnly",false);
        }

    },

    /********************************************************************************************************************
         * @Summary         : Method to fetch the logged in User for displaying his/her name as owner while create request
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateIndividualCustomer
         * @Helper Method   : enableDisableMailingAddress
         * @Apex class      : CB_CreateIndividualCustomerController 
         * @Apex Method     : getLoggedInUserName        
     ********************************************************************************************************************/     
  
    getLoggedInUserForOwner : function(component, event) {
        //Checking if request came for creation
        var record = component.get("v.recordId");
        
        if(record == null || record == undefined){
            
            var action = component.get("c.getLoggedInUserForOwner");

            action.setCallback(this, function(a){ 
       
                var ownerName = a.getReturnValue();
            
                if(ownerName != null && ownerName != undefined){
                
                    component.set("v.loggedInUserOwner",ownerName);
             }   
            });
        $A.enqueueAction(action);
        }

    },

    /********************************************************************************************************************
         * @Summary         : Method to get the relationship
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateBusinessCustomer
         * @Helper Method   : getRelationship
         * @Apex class      : CB_CreateBusinessCustomerController 
         * @Apex Method     : getRelationship        
     ********************************************************************************************************************/     
  
    getRelationship : function(component, event) {

		//Checking if request came for creation or conversion
		var record = component.get("v.recordId");
        if(record != null){
        // calling apex method to fetch child record
        var action = component.get('c.getRelationship');
        
        //sending parameters to the apex method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                component.set('v.relationship', actionResult.getReturnValue());
                if(component.get("v.relationship.CB_MarkAsConfidential__c")){
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "type": "error",
                            "mode": "sticky",
                            "message": "Confidential Relationships cannot be converted to Customer. Contact Confidential Projects Group to convert this to a non-confidential relationship and try again"
                        });
                    toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }
                else if(component.get("v.relationship.CB_Convert_to_Customer__c")){

                    this.checkErrorMatrix(component,event);
                    if(component.get("v.relationship.Mailing_Address_Same_as_Street__c")){
                    	//disabling the mailing address fields
                        component.set("v.MailingAddressReadOnly",true);
                    }
                    component.set("v.onLoadStreetNumber",component.get("v.relationship.BDP_Street_Address_Street_Number__c"));
                    component.set("v.onLoadStreetName",component.get("v.relationship.BDP_Street_Address_Street_Name__c"));
                    component.set("v.onLoadUnitNumber",component.get("v.relationship.BDP_Street_Address_Unit_Number__c"));
                    component.set("v.onLoadZipCode",component.get("v.relationship.BDP_Street_Address_Zip_Code__c"));
                    component.set("v.onLoadZipCode4",component.get("v.relationship.BDP_Street_Address_Zip_Code_4__c"));
                    component.set("v.onLoadForeignLine1",component.get("v.relationship.BDP_Street_Foreign_Address_Line_1__c"));
                    component.set("v.onLoadForeignLine2",component.get("v.relationship.BDP_Street_Foreign_Address_Line_2__c"));
                    component.set("v.onLoadForeignPostalCode",component.get("v.relationship.BDP_Street_Postal_Code__c"));
                    
                    component.set("v.onLoadmailingStreetNumber",component.get("v.relationship.BDP_Mailing_Address_Street_Number__c"));
                    component.set("v.onLoadmailingStreetName",component.get("v.relationship.BDP_Mailing_Address_Street_Name__c"));
                    component.set("v.onLoadmailingUnitNumber",component.get("v.relationship.BDP_Mailing_Address_Unit_Number__c"));
                    component.set("v.onLoadmailingZipCode",component.get("v.relationship.BDP_Mailing_Address_Zip_Code__c"));
                    component.set("v.onLoadmailingZipCode4",component.get("v.relationship.BDP_Mailing_Address_Zip_Code_4__c"));
                    component.set("v.onLoadmailingForeignLine1",component.get("v.relationship.BDP_Mailing_Foreign_Address_Line_1__c"));
                    component.set("v.onLoadmailingForeignLine2",component.get("v.relationship.BDP_Mailing_Foreign_Address_Line_2__c"));
                    component.set("v.onLoadmailingForeignPostalCode",component.get("v.relationship.BDP_Mailing_Postal_Code__c"));
                    
                    var billingState = component.get("v.relationship.BDP_Street_Address_State__c");
        			var billingUnitType = component.get("v.relationship.BDP_Street_Address_Unit_Type__c");
        
                    if(component.get("v.relationship.BDP_Street_Address_Format__c") == 'Street Type Address (Standard)'){
                        component.set("v.IsForeign",false);
                        component.find("billingPostalCode").set("v.value",null);
                    }
                    if(component.get("v.relationship.BDP_Street_Address_Format__c") == 'Foreign Address'){
                        component.set("v.IsForeign",true);
                        component.find("BillingStatePick").set("v.value",null);
                        component.find("billingZipCode").set("v.value",null);
                        component.find("billingZipCode4").set("v.value",null);
                        component.find("BillingUnitTypePick").set("v.value",null);
                        component.find("billingUnitNumber").set("v.value",null);
                    }
                    
                    component.set("v.loggedInUserOwner",component.get("v.relationship.Owner.Name"));
                    var relName = component.get("v.relationship.Name");
                    if(relName.length > 200){
                        var entityName = relName.substring(0,200);
                        component.set("v.relationship.BDP_Entity_Name__c",entityName);
                    }
                    else{
                        component.set("v.relationship.BDP_Entity_Name__c",relName);
                    }
                }
                else{
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "type": "error",
                            "mode": "sticky",
                            "message": "Please check the Convert to Customer checkbox before clicking this button"
                        });
                    toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }
            }
        });
        $A.enqueueAction(action);
        }
		component.set('v.recordTypeName','CB Business Customer');
		var picklistFields = component.get('c.getPicklistValues');
        picklistFields.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
            	var pick = JSON.parse(actionResult.getReturnValue());
            	component.set('v.CustomerStrategy', pick["CB_CustomerStrategy__c"]);
                component.set('v.Industry', pick["Industry"]);
                component.set('v.SalesVolumeRange', pick["CB_SalesVolumeRange__c"]);
                component.set('v.SBNACreditRelationship', pick["CB_SBNA_Participation__c"]);
                component.set('v.SBNACashManagementRelationship', pick["CB_SBNA_CashManagementRelationship__c"]);
                component.set('v.MarketingOptOut', pick["BDP_HasOptedOutOfEmail__c"]);
                component.set('v.Level', pick["CB_Level__c"]);
                component.set('v.MoodysRating', pick["CB_Moody_s_Rating__c"]);
                component.set('v.FitchRating', pick["CB_Fitch_Rating__c"]);
                component.set('v.SandPRating', pick["CB_S_P_Rating__c"]); 
                component.set('v.BillingStreet', pick["BDP_Street_Address_Format__c"]);
                component.set('v.MailingStreet', pick["BDP_Mailing_Address_Format__c"]);
                component.set('v.BillingUnitType', pick["BDP_Street_Address_Unit_Type__c"]);
                component.set('v.MailingUnitType', pick["BDP_Mailing_Address_Unit_Type__c"]);
                component.set('v.BillingState', pick["BDP_Street_Address_State__c"]);
                component.set('v.MailingState', pick["BDP_Mailing_Address_State__c"]);
                component.set('v.PhoneType', pick["BDP_Type__c"]);
                component.set('v.PhoneDescription', pick["BDP_Description__c"]);
				component.set('v.PermanentResidentCountry', pick["Permanent_Resident_Country__c"]); 
				component.set('v.ResidentTaxStatus', pick["BDP_Resident_Status__c"]); 
				component.set('v.TinSsnEin', pick["BDP_ID_Doc_Type__c"]);
                component.set('v.PhoneCountry', pick["PhoneCountry__c"]);
                component.set('v.eddApproval', pick["EDD_Approval__c"]);
                component.set('v.engagedInInternetGambling', pick["Engaged_in_Internet_Gambling__c"]);
                component.set('v.EntityVerificationMethod', pick["Entity_Verification_Method__c"]);
                component.set('v.AccountingSector', pick["BDP_Accounting_Sector__c"]);
                component.set('v.RelationshipToParent', pick["CB_Relationship_to_the_Parent_Company__c"]);
                component.set('v.EmployeesRange', pick["CB_Employee_Range__c"]);
                component.set('v.strategicPillar', pick["CB_Strategic_Pillar_Designation__c"]);
                component.set('v.OwnershipPicklist', pick["Ownership"]);
                component.set('v.BidPicklist', pick["CB_Bid__c"]);
                component.set('v.ImportExportIndicator', pick["CB_Import_Export_Indicator__c"]);
                component.set('v.ImportCountries', pick["CB_IC__c"]);
                component.set('v.ExportCountries', pick["CB_EC__c"]);
                component.set('v.CountryPresence', pick["CB_Presence__c"]);
                component.set('v.InternationalProfile', pick["CB_International_Profile__c"]);
                component.set('v.TradeProgram', pick["CB_Trade_Program__c"]);
                component.set('v.ClientOverseas', pick["CB_Client_Overseas__c"]);
                component.set('v.BillingCountry', pick["BDP_Street_Address_Country__c"]);
                component.set('v.MailingCountry', pick["BDP_Mailing_Address_Country__c"]);
            }
        }); 
        $A.enqueueAction(picklistFields);

	},
/********************************************************************************************************************
         * @Summary         : Method to get the values for dependent picklist fields
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateBusinessCustomer
         * @Helper Method   : getValuesForDependentPicklist
         * @Apex class      : CB_CreateBusinessCustomerController 
         * @Apex Method     : getDependentPicklistValues
     ********************************************************************************************************************/     
  
    getValuesForDependentPicklist : function(component, event) {
        //Checking if request came for creation or conversion
        var record = component.get("v.recordId");
        if(record != null){
            var dependentPicklistField = component.get("c.getDependentPicklistValues");
            //sending parameters to the apex method
            dependentPicklistField.setParams({
                "recordId": component.get("v.recordId")
            });

            dependentPicklistField.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                var pick = JSON.parse(actionResult.getReturnValue());
                for(var i=0;i<Object.keys(pick).length;i++){
                    if(Object.keys(pick)[i] == "BDP_Entity_Type__c"){
                        var controllingValue = pick["BDP_Entity_Type__c"];
                        component.set('v.EntityType',controllingValue);
                        var dependentValue = pick["BDP_Additional_Details__c"];
                        component.set('v.AdditionalDetails',dependentValue);
                        var dependentPicklistComp = component.find("dependentPicklistComponent1");
                        dependentPicklistComp.getLoadMethod(controllingValue,dependentValue);
                    }
                    else if(Object.keys(pick)[i] == "BDP_Country_of_Organization__c"){
                        var controllingValue = pick["BDP_Country_of_Organization__c"];
                        component.set('v.CountryOfOrg',controllingValue);
                        var dependentValue = pick["BDP_State_of_Incorporation__c"];
                        component.set('v.StateOfIncorporation',dependentValue);
                        var dependentPicklistComp = component.find("dependentPicklistComponent2");
                        dependentPicklistComp.getLoadMethod(controllingValue,dependentValue);
                    }
                    
                }
                
            }
            });
         $A.enqueueAction(dependentPicklistField);   
        }
    },

/********************************************************************************************************************
         * @Summary         : Method to get the lookup field values
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateBusinessCustomer
         * @Helper Method   : getLookupValues
         * @Apex class      : CB_CreateBusinessCustomerController 
         * @Apex Method     : getParentRelationLookupValue, getNaicsLookupValue, getPrimaryBankCreditLookupValue, getPrimaryBankCashLookupValue
                              getAttorneyLookupValue, getAccountantLookupValue, getLawFirmLookupValue, getAccountingFirmLookupValue
                              getCMSOFirmLookupValue
     ********************************************************************************************************************/     
  
    getLookupValues : function(component, event) {
        //Checking if request came for creation or conversion
        var record = component.get("v.recordId");
        if(record != null){
            
            //Setting Parent relationship lookup
            var actionParentId = component.get('c.getParentRelationLookupValue');
            //sending parameters to the apex method
            actionParentId.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionParentId.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedParentRelationship', actionResult.getReturnValue());
                        var parentAccLookupComp = component.find("parentAccLookup");
                        parentAccLookupComp.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Parent Account');
                }
            });
            
            //Setting Sponsor - 1 lookup
            var actionSponsor1 = component.get('c.getSponsor1LookupValue');
            //sending parameters to the apex method
            actionSponsor1.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionSponsor1.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedSponsor1', actionResult.getReturnValue());
                        var sponsor1LookupComp = component.find("sponsor1Lookup");
                        sponsor1LookupComp.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Sponsor - 1');
                }
            });

			//Setting Sponsor - 2 lookup
            var actionSponsor2 = component.get('c.getSponsor2LookupValue');
            //sending parameters to the apex method
            actionSponsor2.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionSponsor2.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedSponsor2', actionResult.getReturnValue());
                        var sponsor2LookupComp = component.find("sponsor2Lookup");
                        sponsor2LookupComp.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Sponsor - 2');
                }
            });

            //Setting NAICS lookup
            var actionnaicsLookup = component.get('c.getNaicsLookupValue');
            //sending parameters to the apex method
            actionnaicsLookup.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionnaicsLookup.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedNaics', actionResult.getReturnValue());
                        var naicsLookupComponent = component.find("naicsLookup");
                        naicsLookupComponent.getLoadMethod();
                    }
                }
                else{
                    alert('Error in NAICS');
                }
            });

            //Setting Primary Bank Credit Relationship lookup
            var actionPrimaryBankCreditRelationshipLookup = component.get('c.getPrimaryBankCreditLookupValue');
            //sending parameters to the apex method
            actionPrimaryBankCreditRelationshipLookup.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionPrimaryBankCreditRelationshipLookup.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedPrimaryBankCreditRelationship', actionResult.getReturnValue());
                        var primaryBankCreditLookupComponent = component.find("primaryBankCreditRelationshipLookup");
                        primaryBankCreditLookupComponent.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Primary Bank Credit Relationship');
                }
            });

            //Setting Primary Bank Cash Relationship
            var actionPrimaryBankCashRelationshipLookup = component.get('c.getPrimaryBankCashLookupValue');
            //sending parameters to the apex method
            actionPrimaryBankCashRelationshipLookup.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionPrimaryBankCashRelationshipLookup.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedPrimaryBankCashRelationship', actionResult.getReturnValue());
                        var primaryBankCashLookupComponent = component.find("primaryBankCashRelationshipLookup");
                        primaryBankCashLookupComponent.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Primary Bank Cash Relationship');
                }
            });
			
            $A.enqueueAction(actionParentId);
            $A.enqueueAction(actionnaicsLookup);
            $A.enqueueAction(actionPrimaryBankCreditRelationshipLookup);
            $A.enqueueAction(actionPrimaryBankCashRelationshipLookup);
            $A.enqueueAction(actionSponsor1);
            $A.enqueueAction(actionSponsor2);
        }   
       
    },
/********************************************************************************************************************
         * @Summary         : Method to make the callout to USPS and BDP and save the record
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateBusinessCustomer
         * @Helper Method   : saveRecordHelper
         * @Apex class      : CB_CreateBusinessCustomerController 
         * @Apex Method     : createRecord        
     ********************************************************************************************************************/     
  
    saveRecordHelper : function(component, event) {
        
        var toggleTarget = component.find('mySpinner');
        $A.util.removeClass(toggleTarget, 'slds-hide');
        //Removing the error message first
        component.set("v.errorMessage", null);
        
        if(component.get('v.relationship.BDP_Street_Address_Format__c') == 'Street Type Address (Standard)'){
            if(component.get('v.relationship.BDP_ID_Doc_Type__c') != 'Employer Identification Number (EIN)'){
               $A.util.addClass(toggleTarget, 'slds-hide');
               component.set("v.errorMessage",'Please select Employer Identification Number (EIN) for TIN / SSN / EIN');
            }
        }
        else if(component.get('v.relationship.BDP_Street_Address_Format__c') == 'Foreign Address'){
            var tinNumber = component.get('v.relationship.BDP_ID_Document_Number__c');
            if(component.get('v.CountryOfOrg') != undefined && component.get('v.CountryOfOrg') != null && component.get('v.CountryOfOrg') == 'UNITED STATES'){
         	  $A.util.addClass(toggleTarget, 'slds-hide');
              component.set("v.errorMessage",'Country of Organization cannot be US in case of a Foreign Address'); 
        	}
            else if(tinNumber == undefined || tinNumber == null || (tinNumber != undefined && tinNumber != null && (tinNumber.length == 0 || tinNumber.length > 30))){
                $A.util.addClass(toggleTarget, 'slds-hide');
               component.set("v.errorMessage",'Please enter a valid TIN / SSN / EIN number');
            }
        }
        if(component.get("v.errorMessage") == null){
        //Getting the relationship record
        var relationshipRecord = component.get("v.relationship");
        //Checking if request came for creation or conversion
        var hasAccRecordId = component.get("v.recordId");
        //setting lookup records before upsert
            component.set('v.relationship.ParentId',component.get('v.selectedParentRelationship').Id);
            component.set('v.relationship.NAICS_Code_Description__c',component.get('v.selectedNaics').Id);
            component.set('v.relationship.CB_Primary_Bank__c',component.get('v.selectedPrimaryBankCreditRelationship').Id);
            component.set('v.relationship.CB_PrimaryBankCashRelationship__c',component.get('v.selectedPrimaryBankCashRelationship').Id);
            component.set('v.relationship.Sponsor_1__c',component.get('v.selectedSponsor1').Id);
			component.set('v.relationship.Sponsor_2__c',component.get('v.selectedSponsor2').Id);            
            
            component.set('v.relationship.BDP_Entity_Type__c',component.get('v.EntityType'));
            component.set('v.relationship.BDP_Additional_Details__c',component.get('v.AdditionalDetails'));
            component.set('v.relationship.BDP_Country_of_Organization__c',component.get('v.CountryOfOrg'));
            component.set('v.relationship.BDP_State_of_Incorporation__c',component.get('v.StateOfIncorporation'));

        // calling apex method to fetch child record
        var action = component.get('c.createRecord');
        
        //sending parameters to the apex method
        action.setParams({
            "businessCustomerRelationship" : relationshipRecord
            
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS'){
                var resp = JSON.parse(actionResult.getReturnValue());
                if(resp.isSuccess){
                    console.log('Success'+resp.respMsg);
                    if(resp.recId != null){
                        $A.util.addClass(toggleTarget, 'slds-hide');
                        var dismissActionPanel = $A.get("e.force:closeQuickAction");
                        dismissActionPanel.fire();
                        $A.get("e.force:refreshView").fire();
                    }else{
                        // call the event   
                        var compEvent = component.getEvent("communicate");
                        // set the Selected sObject Record to the event attribute.  
                        compEvent.setParams({"openModalWindow" : false });  
                        // fire the event  
                        compEvent.fire();
                        var res = resp.recId;                    
                        var navEvt = $A.get("e.force:navigateToSObject");
                        navEvt.setParams({
                            "recordId": res
                        });                    
                        navEvt.fire();
                    }
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Saved!",
                        "type": "success",
                        "message": "CB Business Customer Created"
                    });
                    toastEvent.fire();
                }else{
                    $A.util.addClass(toggleTarget, 'slds-hide');
                    console.log('Error'+resp.respMsg);
                    component.set("v.errorMessage",resp.respMsg);
                }
            }else if (state === "ERROR") {
                $A.util.addClass(toggleTarget, 'slds-hide');
                var errors = actionResult.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }

        });
        $A.enqueueAction(action);
        
        }
    },
})