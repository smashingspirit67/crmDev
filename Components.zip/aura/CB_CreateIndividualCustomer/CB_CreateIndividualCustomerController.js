/*************************************************************************************
* @Summary      : Client Side controller for the component CB_CreateIndividualCustomer         
* @Parameters   : Component
* @Parameters   : Event
* @Parameters   : Helper
* @Component    : CB_CreateIndividualCustomer   
* @Helper       : CB_CreateIndividualCustomerHelper.Js 
* @Apex class   : CB_CreateIndividualCustomerController        
***************************************************************************************/      
({

/********************************************************************************************************************
         * @Summary         : Method to initialize values and load the component
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateIndividualCustomer  
         * @Helper Method   : checkErrorMatrix, getRelationshipRec, getLookupValues, getValuesForDependentPicklist
         * @Apex class      : CB_CreateIndividualCustomerController      
********************************************************************************************************************/     
    
	doInit : function(component, event, helper) {
        
        //helper.checkErrorMatrix(component, event);
        helper.getRelationshipRec(component, event);
        helper.getLookupValues(component, event);
        helper.getValuesForDependentPicklist(component, event);
        helper.getLoggedInUserForOwner(component, event);
    },

/********************************************************************************************************************
         * @Summary         : Method to handle the component event to set the values for the picklist value attributes
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateIndividualCustomer  
         * @Helper Method   : N.A
         * @Apex class      : CB_CreateIndividualCustomerController      
********************************************************************************************************************/     

    handleMyPicklistComponentEvent : function(component, event, helper) {
        var cmpName = event.getParam("masterFieldApiName");
        var valueOfControllingField = event.getParam("controllingFieldValue");
        var valueOfDependentField = event.getParam("dependentFieldValue");
        if(cmpName == 'BDP_Employment_Status__c'){
            component.set("v.EmploymentStatus",valueOfControllingField);
            component.set("v.Occupation",valueOfDependentField);
        }
    },

	/********************************************************************************************************************
         * @Summary         : Action to be executed if cancel is clicked in edit mode
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateIndividualCustomer  
         * @Helper Method   : N.A
         * @Apex class      : CB_CreateIndividualCustomerController      
********************************************************************************************************************/     

    closeModal : function(component,event,helper){  
        //checking if it is a create request or convert request
        var record = component.get("v.recordId");
        if(record != null){
            $A.get("e.force:closeQuickAction").fire();
        }
        else{
        // call the event   
        var compEvent = component.getEvent("communicateIndividual");
        // set the Selected sObject Record to the event attribute.  
        compEvent.setParams({"openModalWindowForIndividual" : false });  
        // fire the event  
        compEvent.fire();
        }
    },

/********************************************************************************************************************
         * @Summary         : Action to close the error notification
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateIndividualCustomer  
         * @Helper Method   : NA
         * @Apex class      : CB_CreateIndividualCustomerController      
********************************************************************************************************************/     


    closeErrorPill : function(component,event,helper){  
        //checking if it is a create request or convert request
        component.set('v.errorMessage',null);
    },
/********************************************************************************************************************
         * @Summary         : Action to enable or disable mailing address fields
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateIndividualCustomer  
         * @Helper Method   : enableDisableMailingAddressFields
         * @Apex class      : CB_CreateIndividualCustomerController      
********************************************************************************************************************/     

    enableDisableMailingAddress : function(component, event, helper){
        helper.enableDisableMailingAddressFields(component, event);
    },
 /********************************************************************************************************************
         * @Summary         : Action to be executed if save is clicked in edit mode
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateIndividualCustomer  
         * @Helper Method   : saveRecordHelper
         * @Apex class      : CB_CreateIndividualCustomerController      
********************************************************************************************************************/     
 
    saveRecord : function(component, event, helper) {
        helper.saveRecordHelper(component, event);
    },
    
/********************************************************************************************************************
         * @Summary         : Actions to be executed on changing the selection in picklist fields
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_CreateIndividualCustomer  
         * @Helper Method   : N.A
         * @Apex class      : CB_CreateIndividualCustomerController      
********************************************************************************************************************/     

    
    onSelectChangeCustomerStrategy : function(component, event, helper) {
        var selected = component.find("custStrategy").get("v.value");
        component.set("v.relationship.CB_CustomerStrategy__c", selected);
    },

    onSelectChangeIndustry : function(component, event, helper) {
        var selected = component.find("industryPick").get("v.value");
        component.set("v.relationship.Industry", selected);
    },

    onSelectChangeSalesVolumeRange : function(component, event, helper) {
        var selected = component.find("salesVolumeRangePick").get("v.value");
        component.set("v.relationship.CB_SalesVolumeRange__c", selected);
    },

    onChangeMarketingOptOut : function(component, event, helper) {
        var selected = component.find("marketingOptOut").get("v.value");
        component.set("v.relationship.BDP_HasOptedOutOfEmail__c", selected);
    },

    onChangeLevel : function(component, event, helper) {
        var selected = component.find("levelPick").get("v.value");
        component.set("v.relationship.CB_Level__c", selected);
    },

    onChangeSegmentType : function(component, event, helper) {
        var selected = component.find("SegmentTypePick").get("v.value");
        component.set("v.relationship.BDP_Segment_Type__c", selected);
    },

    onChangeBillingStreet : function(component, event, helper) {
        var selected = component.find("BillingStreetPick").get("v.value");
        component.set("v.relationship.BDP_Street_Address_Format__c", selected);
        
        var billingState = component.get("v.relationship.BDP_Street_Address_State__c");
        var billingUnitType = component.get("v.relationship.BDP_Street_Address_Unit_Type__c");
        
        if(selected == 'Street Type Address (Standard)'){
            component.set("v.IsForeign",false);
            component.find("BillingStatePick").set("v.value",billingState);
            component.find("billingZipCode").set("v.value",component.get("v.onLoadZipCode"));
            component.find("billingZipCode4").set("v.value",component.get("v.onLoadZipCode4"));
            component.find("BillingUnitTypePick").set("v.value",billingUnitType);
            component.find("billingUnitNumber").set("v.value",component.get("v.onLoadUnitNumber"));
            component.find("billingPostalCode").set("v.value",null);
        }
        if(selected == 'Foreign Address'){
            component.set("v.IsForeign",true);
            component.find("BillingStatePick").set("v.value",null);
            component.find("billingZipCode").set("v.value",null);
            component.find("billingZipCode4").set("v.value",null);
            component.find("BillingUnitTypePick").set("v.value",null);
			component.find("billingUnitNumber").set("v.value",null);
            component.find("billingPostalCode").set("v.value",component.get("v.onLoadForeignPostalCode"));
        }
    },

    onChangeMailingStreet : function(component, event, helper) {
        var selected = component.find("MailingStreetPick").get("v.value");
        component.set("v.relationship.BDP_Mailing_Address_Format__c", selected);
        
        var mailingState = component.get("v.relationship.BDP_Street_Address_State__c");
        var mailingUnitType = component.get("v.relationship.BDP_Street_Address_Unit_Type__c");
        
        if(selected == 'Street Type Address (Standard)'){
            component.set("v.IsMailingForeign",false);
            component.find("MailingStatePick").set("v.value",mailingState);
            component.find("mailingZipCode").set("v.value",component.get("v.onLoadmailingZipCode"));
            component.find("mailingZipCode4").set("v.value",component.get("v.onLoadmailingZipCode4"));
            component.find("MailingUnitTypePick").set("v.value",mailingUnitType);
            component.find("mailingUnitNumber").set("v.value",component.get("v.onLoadmailingUnitNumber"));
            component.find("mailingPostalCode").set("v.value",null);
        }
        if(selected == 'Foreign Address'){
            component.set("v.IsMailingForeign",true);
            component.find("MailingStatePick").set("v.value",null);
            component.find("mailingZipCode").set("v.value",null);
            component.find("mailingZipCode4").set("v.value",null);
            component.find("MailingUnitTypePick").set("v.value",null);
			component.find("mailingUnitNumber").set("v.value",null);
            component.find("mailingPostalCode").set("v.value",component.get("v.onLoadmailingForeignPostalCode"));
        }
    },

    onChangeBillingUnitType : function(component, event, helper) {
        var selected = component.find("BillingUnitTypePick").get("v.value");
        component.set("v.relationship.BDP_Street_Address_Unit_Type__c", selected);
    },

    onChangeMailingUnitType : function(component, event, helper) {
        var selected = component.find("MailingUnitTypePick").get("v.value");
        component.set("v.relationship.BDP_Mailing_Address_Unit_Type__c", selected);
    },

    onChangeBillingState : function(component, event, helper) {
        var selected = component.find("BillingStatePick").get("v.value");
        component.set("v.relationship.BDP_Street_Address_State__c", selected);
        if(component.get("v.MailingAddressReadOnly")){
            component.set("v.relationship.BDP_Mailing_Address_State__c", selected);
        }
    },

    onChangeMailingState : function(component, event, helper) {
        var selected = component.find("MailingStatePick").get("v.value");
        component.set("v.relationship.BDP_Mailing_Address_State__c", selected);
    },

    onChangePhoneType : function(component, event, helper) {
        var selected = component.find("PhoneTypePick").get("v.value");
        component.set("v.relationship.BDP_Type__c", selected);
    },

    onChangePhoneCountry : function(component, event, helper) {
        var selected = component.find("PhoneCountryPick").get("v.value");
        component.set("v.relationship.PhoneCountry__c", selected);
    },

    onChangePhoneDescription : function(component, event, helper) {
        var selected = component.find("PhoneDescriptionPick").get("v.value");
        component.set("v.relationship.BDP_Description__c", selected);
    },

    onChangePermanentResidentCountry : function(component, event, helper) {
        var selected = component.find("PermanentResidentCountryPick").get("v.value");
        component.set("v.relationship.Permanent_Resident_Country__c", selected);
    },

    onChangeResidentTaxStatus : function(component, event, helper) {
        var selected = component.find("ResidentTaxStatusPick").get("v.value");
        component.set("v.relationship.BDP_Resident_Status__c", selected);
    },

    onChangeTinSsnEin : function(component, event, helper) {
        var selected = component.find("TinSsnEinPick").get("v.value");
        component.set("v.relationship.BDP_ID_Doc_Type__c", selected);
    },
    
    onSelectChangeEddApproval : function(component, event, helper) {
        var selected = component.find("eddApprovalPick").get("v.value");
        component.set("v.relationship.EDD_Approval__c", selected);
    },

    onSelectChangeInternetGambling : function(component, event, helper) {
        var selected = component.find("engInInternetGambling").get("v.value");
        component.set("v.relationship.Engaged_in_Internet_Gambling__c", selected);
    },
    
    onSelectChangekycAssignedRiskLevel : function(component, event, helper) {
        var selected = component.find("kycAssignedRiskLevelPick").get("v.value");
        component.set("v.relationship.Norkom_KYC_Assigned_Risk_Level__c", selected);
    },
    
    onSelectChangeSalutation : function(component, event, helper) {
        var selected = component.find("salutationPick").get("v.value");
        component.set("v.relationship.BDP_Salutation__c", selected);
    },
    
    onChangeCountryOfBirth : function(component, event, helper) {
        var selected = component.find("CountryOfBirthPick").get("v.value");
        component.set("v.relationship.BDP_Country_of_Birth__c", selected);
    },
    
    onChangeCountryOfCitizenship : function(component, event, helper) {
        var selected = component.find("CountryOfCitizenshipPick").get("v.value");
        component.set("v.relationship.BDP_Country_of_Citizenship__c", selected);
    },
    
    onChangeConfidentiality : function(component, event, helper) {
        var selected = component.find("ConfidentialityPick").get("v.value");
        component.set("v.relationship.BDP_Confidentiality__c", selected);
    },
    
    onChangeOfacScreen : function(component, event, helper) {
        var selected = component.find("ofacScreenPick").get("v.value");
        component.set("v.relationship.BDP_tipoColision__c", selected);
    },
    
    onChangeIdStateOfIssuance : function(component, event, helper) {
        var selected = component.find("IdStateOfIssuancePick").get("v.value");
        component.set("v.relationship.Sole_Prop_ID_State_of_Issuance__c", selected);
    },
    
    onChangeCountryOfOrg : function(component, event, helper) {
        var selected = component.find("CountryOfOrgPick").get("v.value");
        component.set("v.relationship.BDP_Country_of_Organization__c", selected);
    },

    onChangeSuffix : function(component, event, helper) {
        var selected = component.find("SuffixPick").get("v.value");
        component.set("v.relationship.BDP_Suffix__c", selected);
    },

    onSelectChangeSantanderEmployee : function(component, event, helper) {
        var selected = component.find("SantanderEmployeePick").get("v.value");
        component.set("v.relationship.BDP_Santander_Employee_TWA__c", selected);
    },
    
    onChangeRelationshipToParent : function(component, event, helper) {
        var selected = component.find("RelationshipToParentPick").get("v.value");
        component.set("v.relationship.CB_Relationship_to_the_Parent_Company__c", selected);
    },
    
    onChangeBillingCountry : function(component, event, helper) {
        var selected = component.find("BillingCountryPick").get("v.value");
        component.set("v.relationship.BDP_Street_Address_Country__c", selected);
        if(component.get("v.MailingAddressReadOnly")){
         	component.set("v.relationship.BDP_Mailing_Address_Country__c", selected);
        }
    },
    
    onChangeMailingCountry : function(component, event, helper) {
        var selected = component.find("MailingCountryPick").get("v.value");
        component.set("v.relationship.BDP_Mailing_Address_Country__c", selected);
    },

	showHelpText : function(component, event, helper) {
        component.set("v.showHelpForCS",true);
    },

    hideHelpText : function(component, event, helper) {
        component.set("v.showHelpForCS",false);
    },
})