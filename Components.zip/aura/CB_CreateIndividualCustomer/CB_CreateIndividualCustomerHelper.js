/*************************************************************************************
* @Summary      : Client Side helper for the component CB_CreateIndividualCustomer         
* @Parameters   : Component
* @Parameters   : Event
* @Parameters   : Helper
* @Component    : CB_CreateIndividualCustomer   
* @Helper       : N.A 
* @Apex class   : CB_CreateIndividualCustomerController        
***************************************************************************************/      
({

   /********************************************************************************************************************
         * @Summary         : Method to check the error matrix to ensure the request came from a valid user
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateIndividualCustomer  
         * @Helper Method   : checkErrorMatrix
         * @Apex class      : CB_CreateIndividualCustomerController     
********************************************************************************************************************/ 
checkErrorMatrix : function(component, event) {

        //Checking if request came for creation or conversion
        var record = component.get("v.recordId");
        if(record != null){
        var action = component.get("c.checkErrorMatrix"); 
        
        action.setCallback(this, function(a){ 
       
         var returnMsg = a.getReturnValue();
        
         if(returnMsg != 'Success'){
            
            var dismissActionPanel = $A.get("e.force:closeQuickAction");
            dismissActionPanel.fire();

            var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "type": "error",
                    "mode": "sticky",
                    "message": returnMsg
                });
            toastEvent.fire();
            
         }   
    });
        $A.enqueueAction(action);
    }

    },

    /********************************************************************************************************************
         * @Summary         : Method to fetch the logged in User for displaying his/her name as owner while create request
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateIndividualCustomer
         * @Helper Method   : getLoggedInUserForOwner
         * @Apex class      : CB_CreateIndividualCustomerController 
         * @Apex Method     : getLoggedInUserName        
     ********************************************************************************************************************/     
  
    getLoggedInUserForOwner : function(component, event) {
        //Checking if request came for creation
        var record = component.get("v.recordId");
        
        if(record == null || record == undefined){
            
            var action = component.get("c.getLoggedInUserForOwner");

            action.setCallback(this, function(a){ 
       
                var ownerName = a.getReturnValue();
            
                if(ownerName != null && ownerName != undefined){
                
                    component.set("v.loggedInUserOwner",ownerName);
             }   
            });
        $A.enqueueAction(action);
        }

    },

    /********************************************************************************************************************
         * @Summary         : Method to enable or disable mailing address fields
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateIndividualCustomer
         * @Helper Method   : enableDisableMailingAddress
         * @Apex class      : CB_CreateIndividualCustomerController 
         * @Apex Method     : NA        
     ********************************************************************************************************************/     
  
    enableDisableMailingAddressFields : function(component, event) {

        var mailingSameAsBilling = component.find("mailingAddressSame").get("v.value");
        if(mailingSameAsBilling){
            //copying over billing address to mailing address
            component.find("MailingStreetPick").set("v.value",component.get("v.relationship.BDP_Street_Address_Format__c"));
            component.find("mailingStreetNumber").set("v.value",component.find("billingStreetNumber").get("v.value"));
            component.find("mailingStreetName").set("v.value",component.find("billingStreetName").get("v.value"));
            component.find("mailingOptionalLine").set("v.value",component.find("billingOptionalLine").get("v.value"));
            component.find("MailingUnitTypePick").set("v.value",component.find("BillingUnitTypePick").get("v.value"));
            component.find("mailingUnitNumber").set("v.value",component.find("billingUnitNumber").get("v.value"));
            component.find("mailingCity").set("v.value",component.find("billingCity").get("v.value"));
            component.find("MailingStatePick").set("v.value",component.get("v.relationship.BDP_Street_Address_State__c"));
            component.find("mailingZipCode").set("v.value",component.find("billingZipCode").get("v.value"));
            component.find("mailingZipCode4").set("v.value",component.find("billingZipCode4").get("v.value"));
            component.find("mailingValidFromDate").set("v.value",component.find("billingValidFromDate").get("v.value"));
            component.find("MailingCountryPick").set("v.value",component.get("v.relationship.BDP_Street_Address_Country__c"));
            component.find("mailingPostalCode").set("v.value",component.find("billingPostalCode").get("v.value"));
            //disabling the mailing address fields
            component.set("v.MailingAddressReadOnly",true);
        }
        else{
            //copying over billing address to mailing address
            component.find("MailingStreetPick").set("v.value",null);
            component.find("mailingStreetNumber").set("v.value",null);
            component.find("mailingStreetName").set("v.value",null);
            component.find("mailingOptionalLine").set("v.value",null);
            component.find("MailingUnitTypePick").set("v.value",null);
            component.find("mailingUnitNumber").set("v.value",null);
            component.find("mailingCity").set("v.value",null);
            component.find("MailingStatePick").set("v.value",null);
            component.find("mailingZipCode").set("v.value",null);
            component.find("mailingZipCode4").set("v.value",null);
            component.find("mailingValidFromDate").set("v.value",null);
            component.find("MailingCountryPick").set("v.value",null);
            component.find("mailingPostalCode").set("v.value",null);
            //enabling the mailing address fields
            component.set("v.MailingAddressReadOnly",false);
        }

    },

    /********************************************************************************************************************
         * @Summary         : Method to get the relationship and load picklist values
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateIndividualCustomer
         * @Helper Method   : getRelationshipRec
         * @Apex class      : CB_CreateIndividualCustomerController 
         * @Apex Method     : getRelationshipRecord, getPicklistValues      
     ********************************************************************************************************************/     
  
    getRelationshipRec : function(component, event) {
		//Checking if request came for creation or conversion
		var record = component.get("v.recordId");
        
        component.set('v.recordTypeName','CB Individual Customer');
		var picklistFields = component.get('c.getPicklistValuesForFields');
        picklistFields.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
            	var pick = JSON.parse(actionResult.getReturnValue());
            	component.set('v.CustomerStrategy', pick["CB_CustomerStrategy__c"]);
                component.set('v.Industry', pick["Industry"]);
                component.set('v.SalesVolumeRange', pick["CB_SalesVolumeRange__c"]);
                component.set('v.MarketingOptOut', pick["BDP_HasOptedOutOfEmail__c"]);
                component.set('v.Level', pick["CB_Level__c"]);
                component.set('v.BillingStreet', pick["BDP_Street_Address_Format__c"]);
                component.set('v.MailingStreet', pick["BDP_Mailing_Address_Format__c"]);
                component.set('v.BillingUnitType', pick["BDP_Street_Address_Unit_Type__c"]);
                component.set('v.MailingUnitType', pick["BDP_Mailing_Address_Unit_Type__c"]);
                component.set('v.BillingState', pick["BDP_Street_Address_State__c"]);
                component.set('v.MailingState', pick["BDP_Mailing_Address_State__c"]);
                component.set('v.PhoneType', pick["BDP_Type__c"]);
                component.set('v.PhoneDescription', pick["BDP_Description__c"]);
				component.set('v.PermanentResidentCountry', pick["Permanent_Resident_Country__c"]); 
				component.set('v.ResidentTaxStatus', pick["BDP_Resident_Status__c"]);
				component.set('v.TinSsnEin', pick["BDP_ID_Doc_Type__c"]);
                component.set('v.Salutation', pick["BDP_Salutation__c"]);
                component.set('v.eddApproval', pick["EDD_Approval__c"]);
                component.set('v.kycAssignedRiskLevel', pick["Norkom_KYC_Assigned_Risk_Level__c"]);
                component.set('v.CountryOfBirth', pick["BDP_Country_of_Birth__c"]);
                component.set('v.CountryOfCitizenship', pick["BDP_Country_of_Citizenship__c"]);
                component.set('v.Confidentiality', pick["BDP_Confidentiality__c"]);
                component.set('v.ofacScreen', pick["BDP_tipoColision__c"]);
                component.set('v.CountryOfOrg', pick["BDP_Country_of_Organization__c"]);
                component.set('v.IdStateOfIssuance', pick["Sole_Prop_ID_State_of_Issuance__c"]);
                component.set('v.PhoneCountry', pick["PhoneCountry__c"]);
                component.set('v.engagedInInternetGambling', pick["Engaged_in_Internet_Gambling__c"]);
                component.set('v.SegmentType', pick["BDP_Segment_Type__c"]);
                component.set('v.suffix', pick["BDP_Suffix__c"]);
                component.set('v.SantanderEmployee', pick["BDP_Santander_Employee_TWA__c"]);
                component.set('v.RelationshipToParent', pick["CB_Relationship_to_the_Parent_Company__c"]);
                component.set('v.BillingCountry', pick["BDP_Street_Address_Country__c"]);
                component.set('v.MailingCountry', pick["BDP_Mailing_Address_Country__c"]);
            }
            else{
                var errors = actionResult.getError();
                alert("errors");
                alert(errors[0].message);
            }
        }); 
        $A.enqueueAction(picklistFields);
        if(record != null){
        // calling apex method to fetch child record
        var action = component.get('c.getRelationshipRecord');
        
        //sending parameters to the apex method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                component.set('v.relationship', actionResult.getReturnValue());
                if(component.get("v.relationship.CB_MarkAsConfidential__c")){
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "type": "error",
                            "message": "Confidential Relationships cannot be converted to Customer. Contact Confidential Projects Group to convert this to a non-confidential relationship and try again"
                        });
                    toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }
                else if(component.get("v.relationship.CB_Convert_to_Customer__c")){
                    this.checkErrorMatrix(component,event);
                    if(component.get("v.relationship.Mailing_Address_Same_as_Street__c")){
                    	//disabling the mailing address fields
                    	component.set("v.MailingAddressReadOnly",true);
                    }
                    
                    component.set("v.onLoadStreetNumber",component.get("v.relationship.BDP_Street_Address_Street_Number__c"));
                    component.set("v.onLoadStreetName",component.get("v.relationship.BDP_Street_Address_Street_Name__c"));
                    component.set("v.onLoadUnitNumber",component.get("v.relationship.BDP_Street_Address_Unit_Number__c"));
                    component.set("v.onLoadZipCode",component.get("v.relationship.BDP_Street_Address_Zip_Code__c"));
                    component.set("v.onLoadZipCode4",component.get("v.relationship.BDP_Street_Address_Zip_Code_4__c"));
                    component.set("v.onLoadForeignLine1",component.get("v.relationship.BDP_Street_Foreign_Address_Line_1__c"));
                    component.set("v.onLoadForeignLine2",component.get("v.relationship.BDP_Street_Foreign_Address_Line_2__c"));
                    component.set("v.onLoadForeignPostalCode",component.get("v.relationship.BDP_Street_Postal_Code__c"));
                    
                    component.set("v.onLoadmailingStreetNumber",component.get("v.relationship.BDP_Mailing_Address_Street_Number__c"));
                    component.set("v.onLoadmailingStreetName",component.get("v.relationship.BDP_Mailing_Address_Street_Name__c"));
                    component.set("v.onLoadmailingUnitNumber",component.get("v.relationship.BDP_Mailing_Address_Unit_Number__c"));
                    component.set("v.onLoadmailingZipCode",component.get("v.relationship.BDP_Mailing_Address_Zip_Code__c"));
                    component.set("v.onLoadmailingZipCode4",component.get("v.relationship.BDP_Mailing_Address_Zip_Code_4__c"));
                    component.set("v.onLoadmailingForeignLine1",component.get("v.relationship.BDP_Mailing_Foreign_Address_Line_1__c"));
                    component.set("v.onLoadmailingForeignLine2",component.get("v.relationship.BDP_Mailing_Foreign_Address_Line_2__c"));
                    component.set("v.onLoadmailingForeignPostalCode",component.get("v.relationship.BDP_Mailing_Postal_Code__c"));
                                        
                    var billingState = component.get("v.relationship.BDP_Street_Address_State__c");
        			var billingUnitType = component.get("v.relationship.BDP_Street_Address_Unit_Type__c");
        
                    if(component.get("v.relationship.BDP_Street_Address_Format__c") == 'Street Type Address (Standard)'){
                        component.set("v.IsForeign",false);
                        component.find("billingPostalCode").set("v.value",null);
                    }
                    if(component.get("v.relationship.BDP_Street_Address_Format__c") == 'Foreign Address'){
                        component.set("v.IsForeign",true);
                        component.find("BillingStatePick").set("v.value",null);
                        component.find("billingZipCode").set("v.value",null);
                        component.find("billingZipCode4").set("v.value",null);
                        component.find("BillingUnitTypePick").set("v.value",null);
                        component.find("billingUnitNumber").set("v.value",null);
                    }
                    
                    component.set("v.loggedInUserOwner",component.get("v.relationship.Owner.Name"));
                }
                else{
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "type": "error",
                            "message": "Please check the Convert to Customer checkbox before clicking this button"
                        });
                    toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }

            }
        });
        $A.enqueueAction(action);

        }
		

	},
/********************************************************************************************************************
         * @Summary         : Method to get the values for dependent picklist fields
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateIndividualCustomer
         * @Helper Method   : getValuesForDependentPicklist
         * @Apex class      : CB_CreateIndividualCustomerController 
         * @Apex Method     : getDependentPicklistValues
     ********************************************************************************************************************/     
  
    getValuesForDependentPicklist : function(component, event) {
        //Checking if request came for creation or conversion
        var record = component.get("v.recordId");
        if(record != null){
            var dependentPicklistField = component.get("c.getDependentPicklistValues");
            //sending parameters to the apex method
            dependentPicklistField.setParams({
                "recordId": component.get("v.recordId")
            });

            dependentPicklistField.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                var pick = JSON.parse(actionResult.getReturnValue());
                for(var i=0;i<Object.keys(pick).length;i++){
                    if(Object.keys(pick)[i] == "BDP_Employment_Status__c"){
                        var controllingValue = pick["BDP_Employment_Status__c"];
                        component.set('v.EmploymentStatus',controllingValue);
                        var dependentValue = pick["BDP_Occupation__c"];
                        component.set('v.Occupation',dependentValue);
                        var dependentPicklistComp = component.find("dependentPicklistComponent1");
                        dependentPicklistComp.getLoadMethod(controllingValue,dependentValue);
                    }
                }
            }
            });
         $A.enqueueAction(dependentPicklistField);   
        }
    },

/********************************************************************************************************************
         * @Summary         : Method to get the lookup field values
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateIndividualCustomer
         * @Helper Method   : getLookupValues
         * @Apex class      : CB_CreateIndividualCustomerController 
         * @Apex Method     : getParentRelationLookupValue, getNaicsLookupValue, getAttorneyLookupValue, getAccountantLookupValue, 
         * 					  getLawFirmLookupValue, getAccountingFirmLookupValue, getCMSOFirmLookupValue, getBranch
     ********************************************************************************************************************/     
  
    getLookupValues : function(component, event) {
        //Checking if request came for creation or conversion
        var record = component.get("v.recordId");
        if(record != null){
            
            //Setting Parent relationship lookup
            var actionParentId = component.get('c.getParentRelationLookupValue');
            //sending parameters to the apex method
            actionParentId.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionParentId.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedParentRelationship', actionResult.getReturnValue());
                        var parentAccLookupComp = component.find("parentAccLookup");
                        parentAccLookupComp.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Parent Account');
                }
            });
			
            //Setting Ultimate Parent lookup
            var actionUltimateParent = component.get('c.getUltimateParentLookupValue');
            //sending parameters to the apex method
            actionUltimateParent.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionUltimateParent.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedUltimateParent', actionResult.getReturnValue());
                        var ultimateParentLookupComp = component.find("ultimateParentLookup");
                        ultimateParentLookupComp.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Parent Account');
                }
            });

            
            //Setting NAICS lookup
            var actionnaicsLookup = component.get('c.getNaicsLookupValue');
            //sending parameters to the apex method
            actionnaicsLookup.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionnaicsLookup.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedNaics', actionResult.getReturnValue());
                        var naicsLookupComponent = component.find("naicsLookup");
                        naicsLookupComponent.getLoadMethod();
                    }
                }
                else{
                    alert('Error in NAICS');
                }
            });

			//Setting Primary Bank Credit Relationship lookup
            var actionPrimaryBankCreditRelationshipLookup = component.get('c.getPrimaryBankCreditLookupValue');
            //sending parameters to the apex method
            actionPrimaryBankCreditRelationshipLookup.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionPrimaryBankCreditRelationshipLookup.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedPrimaryBankCreditRelationship', actionResult.getReturnValue());
                        var primaryBankCreditLookupComponent = component.find("primaryBankCreditRelationshipLookup");
                        primaryBankCreditLookupComponent.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Primary Bank Credit Relationship');
                }
            });

            //Setting Primary Bank Cash Relationship
            var actionPrimaryBankCashRelationshipLookup = component.get('c.getPrimaryBankCashLookupValue');
            //sending parameters to the apex method
            actionPrimaryBankCashRelationshipLookup.setParams({
                "recordId": component.get("v.recordId")
            });
        
            actionPrimaryBankCashRelationshipLookup.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === 'SUCCESS') {
                    if(actionResult.getReturnValue()!=null){
                        component.set('v.selectedPrimaryBankCashRelationship', actionResult.getReturnValue());
                        var primaryBankCashLookupComponent = component.find("primaryBankCashRelationshipLookup");
                        primaryBankCashLookupComponent.getLoadMethod();
                    }
                }
                else{
                    alert('Error in Primary Bank Cash Relationship');
                }
            });
            
            $A.enqueueAction(actionParentId);
            $A.enqueueAction(actionnaicsLookup);
            $A.enqueueAction(actionUltimateParent);
            $A.enqueueAction(actionPrimaryBankCreditRelationshipLookup);
            $A.enqueueAction(actionPrimaryBankCashRelationshipLookup);
        }   
       
    },
/********************************************************************************************************************
         * @Summary         : Method to make the callout to USPS and BDP and save the record
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreateBusinessCustomer
         * @Helper Method   : saveRecordHelper
         * @Apex class      : CB_CreateBusinessCustomerController 
         * @Apex Method     : createRecord        
     ********************************************************************************************************************/     
  
    saveRecordHelper : function(component, event) {
        
        var toggleTarget = component.find('mySpinner');
        $A.util.removeClass(toggleTarget, 'slds-hide');
        //Removing the error message first
        component.set("v.errorMessage", null);
        //Getting the relationship record
        var relationshipRecord = component.get("v.relationship");
        
        if(component.get('v.relationship.BDP_Street_Address_Format__c') == 'Street Type Address (Standard)'){
            if(component.get('v.relationship.BDP_ID_Doc_Type__c') != 'Social Security Number'){
               $A.util.addClass(toggleTarget, 'slds-hide');
               component.set("v.errorMessage",'Please select Social Security Number for TIN / SSN / EIN');
            }
        }
        
        else if(component.get('v.relationship.BDP_Street_Address_Format__c') == 'Foreign Address'){
            var tinNumber = component.get('v.relationship.BDP_ID_Document_Number__c');
            
            if(component.get('v.relationship.BDP_Country_of_Organization__c') != undefined && component.get('v.relationship.BDP_Country_of_Organization__c') != null && component.get('v.relationship.BDP_Country_of_Organization__c') == 'UNITED STATES'){
         	  $A.util.addClass(toggleTarget, 'slds-hide');
              component.set("v.errorMessage",'Country of Organization cannot be US in case of a Foreign Address'); 
        	}
            else if(component.get('v.relationship.BDP_Country_of_Citizenship__c') != undefined && component.get('v.relationship.BDP_Country_of_Citizenship__c') != null && component.get('v.relationship.BDP_Country_of_Citizenship__c') == 'UNITED STATES'){
         	  $A.util.addClass(toggleTarget, 'slds-hide');
              component.set("v.errorMessage",'Country of Citizenship cannot be US in case of a Foreign Address'); 
        	}
            else if(component.get('v.relationship.BDP_Resident_Status__c') != 'Non-Resident Alien'){
               $A.util.addClass(toggleTarget, 'slds-hide');
               component.set("v.errorMessage",'Please select Non-Resident Alien for Resident Tax Status');
            }
            if(component.get('v.relationship.BDP_ID_Doc_Type__c') == 'Individual Tax Identification Number (ITIN)'){
               $A.util.addClass(toggleTarget, 'slds-hide');
               component.set("v.errorMessage",'Please select a valid TIN / SSN / EIN');
            }
            else if(tinNumber == undefined || tinNumber == null || (tinNumber != undefined && tinNumber != null && (tinNumber.length == 0 || tinNumber.length > 30))){
                $A.util.addClass(toggleTarget, 'slds-hide');
               component.set("v.errorMessage",'Please enter a valid TIN / SSN / EIN number');
            }
        }
        if(component.get("v.errorMessage") == null){
        //Checking if request came for creation or conversion
        var hasAccRecordId = component.get("v.recordId");
        //setting lookup records before upsert
            component.set('v.relationship.ParentId',component.get('v.selectedParentRelationship').Id);
            component.set('v.relationship.NAICS_Code_Description__c',component.get('v.selectedNaics').Id);
        	component.set('v.relationship.CB_ULTIMATE_PARENT__c',component.get('v.selectedUltimateParent').Id);
            component.set('v.relationship.CB_Primary_Bank__c',component.get('v.selectedPrimaryBankCreditRelationship').Id);
            component.set('v.relationship.CB_PrimaryBankCashRelationship__c',component.get('v.selectedPrimaryBankCashRelationship').Id);
            component.set('v.relationship.BDP_Employment_Status__c',component.get('v.EmploymentStatus'));
            component.set('v.relationship.BDP_Occupation__c',component.get('v.Occupation'));
        
        // calling apex method to fetch child record
        var action = component.get('c.createRecord');
        
        //sending parameters to the apex method
        action.setParams({
            "individualCustomerRelationship" : relationshipRecord
            
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS'){
                var mapOfResponse = JSON.parse(actionResult.getReturnValue());
                if(mapOfResponse.isSuccess){
                    
                    if(mapOfResponse.recId != null){
                        $A.util.addClass(toggleTarget, 'slds-hide');
                        var dismissActionPanel = $A.get("e.force:closeQuickAction");
                        dismissActionPanel.fire();
                        $A.get("e.force:refreshView").fire();
                    }
                    else{
                         // call the event   
                        var compEvent = component.getEvent("communicateIndividual");
                        // set the Selected sObject Record to the event attribute.  
                        compEvent.setParams({"openModalWindowForIndividual" : false });  
                        // fire the event  
                        compEvent.fire();

                        var res = mapOfResponse.recId;
                        alert(res);
                        var navEvt = $A.get("e.force:navigateToSObject");
                        navEvt.setParams({

                        "recordId": res
                 
                        });

                        navEvt.fire();
                 
                    }
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Saved!",
                            "type": "success",
                            "message": "CB Individual Customer Created"
                        });
                    toastEvent.fire();
                }
                else{
                    $A.util.addClass(toggleTarget, 'slds-hide');
                    console.log('Error'+mapOfResponse.respMsg);
                    component.set("v.errorMessage",mapOfResponse.respMsg);
                }
                }/*
                else{
                    /*
                    var errorMsg = mapOfResponse.respMsg;
                    if(errorMsg.includes('Address Not Found')){
                        var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "Address Not Found",
                                "type": "error",
                                "message": "Fill in valid mailing address or billing address field values before saving the record"
                            });
                        toastEvent.fire();
                    }
                    else if(errorMsg.includes('Invalid City')){
                        var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "Invalid City",
                                "type": "error",
                                "message": "Fill in valid mailing address or billing address field values before saving the record"
                            });
                        toastEvent.fire();
                    }
                    else if(errorMsg.includes('Error USPS')){
                        //setting the attribute to display the error message for mandatory fields
                        var errMsg = mapOfResponse.respMsg;
                        if(component.get("v.recordId") != null){
                            component.set("v.errorMessage",errMsg);
                        }
                        else{
                        var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "type": "error",
                                "message": errMsg,
                                "mode": "sticky"
                            });
                        toastEvent.fire();
                        }
                    }
                    else{
                        //setting the attribute to display the error message for mandatory fields
                        var errMsg = mapOfResponse.respMsg;
                        if(component.get("v.recordId") != null){
                            component.set("v.errorMessage",errMsg);
                        }
                        else{
                        var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "type": "error",
                                "message": errMsg,
                                "mode": "sticky"
                            });
                        toastEvent.fire();
                        }
                    }
                }*/
                //setting the attribute to display the error message for mandatory fields
                   /*     var errMsg = mapOfResponse.respMsg;
                        if(component.get("v.recordId") != null){
                            component.set("v.errorMessage",errMsg);
                        }
                        else{
                        var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "type": "error",
                                "message": errMsg,
                                "mode": "sticky"
                            });
                        toastEvent.fire();
                        }
                    }
                
            }*/
            else if (state === "ERROR") {
                $A.util.addClass(toggleTarget, 'slds-hide');
                var errors = actionResult.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }

        });
        $A.enqueueAction(action);
        }

    },
})