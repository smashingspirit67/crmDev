/*************************************************************************************
* @Summary 		: Client Side controller for the component CB_CreditProfileTabComponent         
* @Parameters 	: Component
* @Parameters 	: Event
* @Parameters 	: Helper
* @Component 	: CB_CreditProfileTabComponent   
* @Helper 		: CB_CreditProfileTabComponentHelper 
* @Apex class 	: CB_CreditProfileTabController  
***************************************************************************************/         

({
    doInit : function(component, event, helper) {
        
        helper.getRelationship(component, event);
        helper.getUserAccess(component, event);
        helper.getUserProfile(component, event);
    },
    //Methods to control the collapse/expand behaviour of page sections
    sectionOne : function(component, event, helper) {
       helper.helperCollapse(component,event,'articleOne');
    },
    sectionTwo : function(component, event, helper) {
      helper.helperCollapse(component,event,'articleTwo');
    },
    sectionThree : function(component, event, helper) {
      helper.helperCollapse(component,event,'articleThree');
   	},
	sectionFour : function(component, event, helper) {
      helper.helperCollapse(component,event,'articleFour');
   	},
    
    //Action to be executed on click of edit icon
    changeEditLayout : function(component, event, helper) {
        var isEditAccess = component.get("v.UserHasAccess");
        if(isEditAccess){
            component.set("v.isEditPage", true);
            helper.removeDivider();
            helper.removeEditIcon();
        }
        else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                       "title": "Insufficient Privilege",
                       "type": "error",
                	   "mode": "sticky",
                       "message": "You do not have sufficient privileges to edit this record."
                        });
            toastEvent.fire();
        }
    },
    
    //Action to be executed if cancel is clicked in edit mode
    clickCancel : function(component, event, helper) {
        component.set("v.isEditPage", false);
        helper.addDivider();
        helper.addEditIcon();
        $A.get('e.force:refreshView').fire();
    },
    
    //Action to be executed if save is clicked in edit mode
    clickSave : function(component, event, helper) {
        helper.saveRecord(component, event);
    },
    
    //Actions to be executed on changing the selection in picklist fields
    
    onSelectChange7 : function(component, event, helper) {
        var selected = component.find("option7").get("v.value");
        component.set("v.relationship.CB_BDP_RiskLevel__c", selected);
    },
    
    onSelectChange10 : function(component, event, helper) {
        var selected = component.find("option10").get("v.value");
        component.set("v.relationship.FEVE_Rating__c", selected);
    },
    
    onMultiSelectChange : function(component, event, helper) {
        var selected = component.find("InputSelectMultiple").get("v.value");
        component.set("v.relationship.FEVE_Rating_Reason__c", selected);
    }
})