({
    /********************************************************************************************************************
         * @Summary 		: Method to set the value for ActionPlan attribute of the component on load of the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_CreditProfileTabComponent 
         * @Helper Method 	: getRelationship
         * @Apex class 		: CB_CreditProfileTabController 
         * @Apex Method 	: getRelationship        
     ********************************************************************************************************************/     
    
    getRelationship : function(component, event) {
        
        // calling apex method to fetch child record
        var action = component.get('c.getRelationship');
        
        //sending parameters to the apex method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                component.set('v.relationship', actionResult.getReturnValue());
                var picklistFields = component.get('c.getPicklistValues');
                picklistFields.setCallback(this, function(actionResult) {
            		var state = actionResult.getState();
            		if (state === 'SUCCESS') {
                        var pick = JSON.parse(actionResult.getReturnValue());
                        component.set('v.FeveRatingReason', pick["FEVE_Rating_Reason__c"]);
                        component.set('v.kycAssignedRiskLevel', pick["CB_BDP_RiskLevel__c"]);
                        component.set('v.feveRating', pick["FEVE_Rating__c"]);
                    }
                }); 
                $A.enqueueAction(picklistFields);
            }
        });
        $A.enqueueAction(action);	  
    },
    
    /********************************************************************************************************************
         * @Summary         : Method to set the value for isSystemAdmin attribute of the component on load of the component      
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreditProfileTabComponent 
         * @Helper Method   : getUserAccess
         * @Apex class      : CB_CreditProfileTabController 
         * @Apex Method     : getProfileOfLoggedInUser       
     ********************************************************************************************************************/     
  
    getUserAccess : function(component, event) {

        var action = component.get('c.getAccessOfLoggedInUser');
        //sending parameters to the apex method
        action.setParams({
            "recId" : component.get('v.recordId')
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                component.set('v.UserHasAccess', actionResult.getReturnValue());
            }
        });
        $A.enqueueAction(action);     
    },
    
    /********************************************************************************************************************
         * @Summary         : Method to set the value for isSystemAdmin attribute of the component on load of the component      
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_CreditProfileTabComponent 
         * @Helper Method   : getUserProfile
         * @Apex class      : CB_CreditProfileTabController 
         * @Apex Method     : getProfileOfLoggedInUser       
     ********************************************************************************************************************/     
  
    getUserProfile : function(component, event) {

        var action = component.get('c.getProfileOfLoggedInUser');
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                component.set('v.isSystemAdmin', actionResult.getReturnValue());
            }
        });
        $A.enqueueAction(action);     
    },
    /********************************************************************************************************************
         * @Summary 		: Method to save the edited values of the relationship record      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_CreditProfileTabComponent  
         * @Helper Method 	: saveRecord
         * @Apex class 		: CB_CreditProfileTabController 
         * @Apex Method 	: UpdateRelationship        
     ********************************************************************************************************************/     
    
    saveRecord : function(component, event) {
        // calling apex method to fetch child record
        var action = component.get('c.UpdateRelationship');
        
        var relationshipRecord = component.get("v.relationship");
        
        //sending parameters to the apex method
        action.setParams({
            "acc" : relationshipRecord
            
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS'){
                if(actionResult.getReturnValue() == null){
                    //making the page read-only
                    component.set("v.isEditPage", false);
                    var addDiv = document.getElementsByClassName("hasDiv");
                    for(var i=0; i<addDiv.length; i++){
                        addDiv[i].classList.add("slds-has-divider--bottom");
                    }
                    var addIcon = document.getElementsByClassName("editIcon");
                    for(var i=0; i<addIcon.length; i++){
                        addIcon[i].classList.remove("slds-hide");
                    }
                    //Reloading the view
                    $A.get('e.force:refreshView').fire();
                    //preparing a toast message to confirm that the	record has been saved
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Saved!",
                            "type": "success",
                            "message": "The record has been updated successfully."
                        });
                    toastEvent.fire();
                }
                else{
                    //preparing a toast message to display the error message
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "title": "ERROR",
                        "mode": "sticky",
                        "message": actionResult.getReturnValue()
                    });
                    toastEvent.fire();
                }
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }

        }
                          );
        $A.enqueueAction(action);
        

    },
    
    /********************************************************************************************************************
         * @Summary 		: Method to control the expand/collapse behaviour of page sections
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Parameters 		: secId
         * @Component 		: CB_CreditProfileTabComponent  
         * @Helper Method 	: helperCollapse
         * @Apex class 		: CB_CreditProfileTabController 
         * @Apex Method 	: N.A        
     ********************************************************************************************************************/     
    
    helperCollapse : function(component,event,secId) {
	  var acc = component.find(secId);
        	for(var cmp in acc) {
        	$A.util.toggleClass(acc[cmp], 'slds-show');  
        	$A.util.toggleClass(acc[cmp], 'slds-hide');  
       }
	},
    
     /********************************************************************************************************************
         * @Summary 		: Method to change the page to read only mode
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_CreditProfileTabComponent  
         * @Helper Method 	: addDivider
         * @Apex class 		: CB_CreditProfileTabController 
         * @Apex Method 	: N.A        
     ********************************************************************************************************************/     
    
    addDivider : function() {
    	var x = document.getElementsByClassName("hasDiv");
    	for(var i=0; i<x.length; i++){
    	x[i].classList.add("slds-has-divider--bottom");
		}
 	},
 
     /********************************************************************************************************************
         * @Summary 		: Method to change the page to editable mode
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_CreditProfileTabComponent  
         * @Helper Method 	: removeDivider
         * @Apex class 		: CB_CreditProfileTabController 
         * @Apex Method 	: N.A         
     ********************************************************************************************************************/     
    
 	removeDivider : function() {
   		var x = document.getElementsByClassName("hasDiv");
    	for(var i=0; i<x.length; i++){
        x[i].classList.remove("slds-has-divider--bottom");
    	} 
	},
    
     /********************************************************************************************************************
         * @Summary 		: Method to change the page to read only mode and add the edit icon to fields
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_CreditProfileTabComponent  
         * @Helper Method 	: addEditIcon
         * @Apex class 		: CB_CreditProfileTabController 
         * @Apex Method 	: N.A         
     ********************************************************************************************************************/     
    
    addEditIcon : function() {
        var x = document.getElementsByClassName("editIcon");
        for(var i=0; i<x.length; i++){
            x[i].classList.remove("slds-hide");
        }
    },
      
     /********************************************************************************************************************
         * @Summary 		: Method to change the page to edit mode and remove the edit icon from fields
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_CreditProfileTabComponent  
         * @Helper Method 	: removeEditIcon
         * @Apex class 		: CB_CreditProfileTabController 
         * @Apex Method 	: N.A        
     ********************************************************************************************************************/     
    
    removeEditIcon : function() {
        var x = document.getElementsByClassName("editIcon");
        for(var i=0; i<x.length; i++){
            x[i].classList.add("slds-hide");
        } 
    }

})