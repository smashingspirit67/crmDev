/*************************************************************************************
* @Summary 		: Client Side controller for the component CB_ActionPlanComponent         
* @Parameters 	: Component
* @Parameters 	: Event
* @Parameters 	: Helper
* @Component 	: CB_CustomLookupComponent   
* @Helper 		: CB_CustomLookupComponentHelper 
* @Apex class 	: CB_CustomLookupServerController        
***************************************************************************************/        

({
    //Method to initialize values and load the component
    doInit: function(component, event, helper) {
        
        var isParentAvailable = component.get("v.selectedRecord").Id;
        
        if(isParentAvailable == null){
            var pillTarget = component.find("lookup-pill");
            var lookUpTarget = component.find("lookupField"); 
            
            $A.util.addClass(pillTarget, 'slds-hide');
            $A.util.removeClass(pillTarget, 'slds-show');
            
            $A.util.addClass(lookUpTarget, 'slds-show');
            $A.util.removeClass(lookUpTarget, 'slds-hide');
            
        }
        else{
            var forclose = component.find("lookup-pill");
            $A.util.addClass(forclose, 'slds-show');
            $A.util.removeClass(forclose, 'slds-hide');
            
            
            var forclose = document.getElementById(component.get('{!v.label}')).parentNode;
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
            
            var lookUpTarget = component.find("lookupField");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show'); 
        }
    },
    //Method to display 5 records sorted by created date in descending order when a user clicks in the lookup field
    onfocus : function(component,event,helper){
        var forOpen = document.getElementById(component.get('{!v.label}')).parentNode;
        $A.util.addClass(forOpen, 'slds-is-open');
        $A.util.removeClass(forOpen, 'slds-is-close');
        // Get Default 5 Records order by createdDate DESC  
        var getInputkeyWord = '';
        helper.searchHelper(component,event,getInputkeyWord);
    },

    //Method to display list of 5 records only when user enters atleast 3 characters in the input field
    keyPressController : function(component, event, helper) {
        // get the search Input keyword  
        var getInputkeyWord = component.get("v.SearchKeyWord");
        // check if getInputKeyWord size id is greater or more than 3 then open the lookup result List and 
        // call the helper 
        // else close the lookup result List part.   
        if( getInputkeyWord.length >= 3 ){
            var forOpen = document.getElementById(component.get('{!v.label}')).parentNode;
            // debugger;
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchRecords", null ); 
            var forclose = document.getElementById(component.get('{!v.label}')).parentNode;
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
        
    },
    
    // function for clear the Record Selaction 
    clear :function(component,event,helper){
        
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
        component.set("v.selectedRecord", {} );
        
    },
    
    // This function is called when the end User selects any record from the result list.   
    handleComponentEvent : function(component, event, helper) {
        // get the selected Account record from the COMPONENT event 	 
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        
        component.set("v.selectedRecord" , selectedAccountGetFromEvent); 
        
        var forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        
        
        var forclose = document.getElementById(component.get('{!v.label}')).parentNode;
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');  
        
    },
    
    
})