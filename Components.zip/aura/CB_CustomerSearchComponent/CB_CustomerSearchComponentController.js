({
    
    /**
         * @Summary : Method to see if all fields are filled and search the data base.         
         * @Parameters : Component
         * @Parameters : Event
         * @Parameters : Helper
         * @Component : CB_CustomerSearchComponent   
         * @Helper : CB_CustomerSearchComponentHelper  
         * @Helper Method : getSearchDetails
         * @Apex class : CB_CustomerSearchMock 
         * @Apex Method :getSearchResponse        
     **/        
    
    Search: function (cmp, evt, helper) {
        var toggleTarget = cmp.find('mySpinner');
        $A.util.removeClass(toggleTarget, 'slds-hide');
        var radioselected = cmp.get('v.storeRadioValue');               
        cmp.set('v.ImportDisabled',false);
        if(radioselected == 'custType'){
            var inputCmp = cmp.find("custType1");
            
            if(inputCmp.get('v.value') == 'Business '){
                var inputCmp1 = cmp.find("custname");
                if (inputCmp.get("v.validity").valid && inputCmp1.get("v.validity").valid) {
                    helper.getSearchDetails_RelationName(cmp, event, helper, inputCmp.get('v.value'), inputCmp1.get('v.value'), null, null, toggleTarget);     
                }
                else {            
                    cmp.set("v.SearchResponse[0]","empty");
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "duration": 25000,
                        "message": "All fields are required."
                    });
                    toastEvent.fire();
                    $A.util.addClass(toggleTarget, 'slds-hide');
                }
            }
            else if(inputCmp.get('v.value') == 'Individual '){
                var inputCmp2 = cmp.find("firstname");
                var inputCmp3 = cmp.find("lastname");
                if (inputCmp.get("v.validity").valid && inputCmp2.get("v.validity").valid && inputCmp3.get("v.validity").valid) {
                    helper.getSearchDetails_RelationName(cmp, event, helper, inputCmp.get('v.value'), null, inputCmp2.get('v.value'), inputCmp3.get('v.value'), toggleTarget);     
                }
                else {            
                    cmp.set("v.SearchResponse[0]","empty");
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "duration": 25000,
                        "message": "All fields are required."
                    });
                    toastEvent.fire();
                    $A.util.addClass(toggleTarget, 'slds-hide');
                }
            }
            else {            
                    cmp.set("v.SearchResponse[0]","empty");
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "duration": 25000,
                        "message": "All fields are required."
                    });
                    toastEvent.fire();
                    $A.util.addClass(toggleTarget, 'slds-hide');
            }
        } else if(radioselected == 'docName'){            
            var inputCmp3 = cmp.find("custType3");
            var inputCmp4 = cmp.find("custType4");
            var inputCmp5 = cmp.find("custType5");
            
            if(inputCmp3.get("v.validity").valid && inputCmp4.get("v.validity").valid  && inputCmp5.get("v.validity").valid ){         
                // if(inputCmp3.get('v.value')!= null && inputCmp4.get('v.value')!= null  && inputCmp5.get('v.value') != null ){
                helper.getSearchDetails_DocumentType(cmp, event, helper, inputCmp3.get('v.value'), inputCmp4.get('v.value'), inputCmp5.get('v.value'), toggleTarget);
            }else{
                cmp.set("v.SearchResponse[0]","empty");
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "duration": 25000,
                    "message": "All fields are required."
                });
                toastEvent.fire();  
                $A.util.addClass(toggleTarget, 'slds-hide');                     
            }
            
        } else if(radioselected == 'BDPID') {
            
            var custType2 = cmp.find("custType2");
            var BDPIDinput = cmp.find("BDPIDInput");
            
            if (custType2.get("v.validity").valid && BDPIDinput.get("v.validity").valid) {
                helper.getSearchDetails_RelationType(cmp, event, helper, custType2.get('v.value'), BDPIDinput.get('v.value'), toggleTarget);     
            } else {            
                //toastr.info("Info Message", "Title");
                cmp.set("v.SearchResponse[0]","empty");
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "duration": 25000,
                    "message": "All fields are required."
                });
                toastEvent.fire();
                $A.util.addClass(toggleTarget, 'slds-hide');
            }
        }
    },
    
    
    /**
         * @Summary : Method to hide and show input box based on radio button selected.         
         * @Parameters : Component
         * @Parameters : Event
         * @Component : CB_CustomerSearchComponent   
         * @Helper : CB_CustomerSearchComponentHelper  
         * @Helper Method : N/A
         * @Apex class : CB_CustomerSearchMock 
         * @Apex Method :N/A        
     **/        
    handleSingleRadio: function (cmp, event) {  
        
        var valueRed = event.getSource().get("v.value");
        cmp.set('v.storeRadioValue',valueRed);
        
        cmp.set('v.CusttypeDisabled',false);
        cmp.set('v.ImportDisabled',false);
        
        
        //alert(valueRed);
        
        cmp.set("v.SearchResponse[0]","empty");
        //To show text input when radio is selected
        if(valueRed == 'custType'){
            var cmpTarget = cmp.find('input1');
            var cmpTarget1 = cmp.find('input2');
            var cmpTarget2 = cmp.find('input3');
            $A.util.addClass(cmpTarget, 'changeMe');
            $A.util.removeClass(cmpTarget1, 'changeMe');
            $A.util.removeClass(cmpTarget2, 'changeMe');
            
        }
        
        if(valueRed == 'BDPID'){
            var cmpTarget = cmp.find('input1');
            var cmpTarget1 = cmp.find('input2');
            var cmpTarget2 = cmp.find('input3');
            $A.util.addClass(cmpTarget2, 'changeMe');
            $A.util.removeClass(cmpTarget1, 'changeMe');
            $A.util.removeClass(cmpTarget, 'changeMe');
            
        }
        
        if(valueRed == 'docName'){
            var cmpTarget = cmp.find('input1');
            var cmpTarget1 = cmp.find('input2');
            var cmpTarget2 = cmp.find('input3');
            $A.util.addClass(cmpTarget1, 'changeMe');
            $A.util.removeClass(cmpTarget, 'changeMe');         
            $A.util.removeClass(cmpTarget2, 'changeMe');
        } 
        
        cmp.set('v.buttonDisabled',false);
    },    
    
    //New prospect button click
    handleSaveProspectRecord : function(component,event,helper){
        
        //boolean zero value means indivitual prospect 
        // boolean one means business prospect 
        
        // var recordtype = component.find('custType2');  
        
        helper.SaveProspectRecord(component,event,component.get('v.selectedRecordtype')); 
        
        
    },
    
    //this attb is set to selcet the recordtype once the button is clicked
    
    recordtypetoset :function(component,event,helper){         
        
        var target = event.getSource().get('v.value'); 
        component.set('v.selectedRecordtype',target);
        component.set('v.CusttypeDisabled',false);
        component.set("v.SearchResponse[0]","empty");
    },
    
    //Method to close the popup window in case of Business Customer
    handleComponentEvent: function(component, event, helper) {
        // To Hide/Close Modal window,set the "isOpenModal" attribute to "Fasle"  
        var trueOrFalse = event.getParam("openModalWindow");
        
        component.set("v.isOpenModal" , trueOrFalse); 
    },
    
    //Method to close the popup window in case of Individual Customer
    handleSecondEvent: function(component, event, helper) {
        // To Hide/Close Modal window,set the "isOpenModal" attribute to "Fasle"  
        var trueOrFalse = event.getParam("openModalWindowForIndividual");
        
        component.set("v.isOpenModalForIndividual" , trueOrFalse); 
    },
    
    //Method to open the modal window to create a new Action Plan record
    openModalWindow: function(component, event, helper) {
        
        //To Open Modal window,set the "isOpenModal" attribute to "True"  
        helper.openModalWindow(component, event,component.get('v.selectedRecordtype'));
    },
    //Method to close the popup window
    closeModal: function(component, event, helper) {
        // To Hide/Close Modal window,set the "isOpenModal" attribute to "Fasle"  
        helper.closeModal(component, event);
    },
    
    //New customer button click
    handleSaveCustomerRecord : function(component,event,helper){
        //boolean zero value means indivitual customer 
        // boolean one means Business customer 
        
        //var recordtype = component.find('custType2');
        helper.SaveCustomerRecord(component,event,component.get('v.selectedRecordtype')); 
        
    },
    
    //Flow would be from button to this controller and new method in handler.  
    handleSaveAccountPartner : function(component,event,helper){
        helper.SaveAccountPartnerRecord(component,event,'Account Partners'); 
    },
    
 /************************************************************************
     * Added for the Upper Business Banking Account Partner Record Creation
     * Created BY : Bhaskar Mishra
     * Created Date : 25th September 2018
    /************************************************************************/
    handleSaveUBBAccountPartner : function(component,event,helper){
        helper.createUBBAccountPartnerRecord(component,event); 
    },
    
    
    /*****************************************************************
     * Added for the Upper Business Banking Group Record Creation
     * Created BY : Bhaskar Mishra
     * Created Date : 25th September 2018
    /****************************************************************/
    handleSaveUBBGroupRecord : function(component,event,helper){
        helper.createUBBGroupRecord(component,event); 
    },
    /* Pradeep Dani - updated the handle Import with necessary changes*/
    handleImport : function(component,event,helper){
        var toggleSpinner = component.find('mySpinner');
        $A.util.removeClass(toggleSpinner, 'slds-hide');
        helper.handleImportFunction(component,event,toggleSpinner); 
        /* If needed we can initiate the search again
        var a = component.get('c.Search');
        a.setParams({
            'component':component,'event':event,'helper':helper               
        });
        $A.enqueueAction(a);    */   
    },
    
    /* Ritesh Shahare - updated for saving the selecetd business type to an attribute
    handleMainRadio :  function(component,event,helper){         
        var busType = event.getSource().get("v.value");
        
        if(busType=='COM_Bank')
            component.set('v.businessType','CommercialBanking');
        
        else
            component.set('v.businessType','BusinessBanking');
        
        component.set('v.mainSubmitDisabled',false);   
        
    },  */
    //Functionality added lated as per new user story.
    //Flow would be from button to this controller and new method in handler.  
    handleSaveGroupRecord : function(component,event,helper){
        
        helper.SaveGroupRecord(component,event,'Group'); 
        
    },
    
	/* Ritesh Shahare - handle business button's events*/
    handleBussinessButtons:function(component,event,helper){
        var Buttonclicked=event.getSource().getLocalId();
        var SelectRelType=event.getSource().get("v.value");
        var navigationURL="";
        
        if(Buttonclicked=='CreateHousehold'){
            	navigationURL= "/apex/Customer?rectype=Household";
        }else if(Buttonclicked=='CreateVendor'){
            	navigationURL= "/apex/Customer?rectype=Vendor_Attorney";
        }else if(Buttonclicked=='CreateProspect' && SelectRelType=='Individual '){
                 navigationURL= "/apex/Customer?rectype=Individual_Prospect";
        }else if(Buttonclicked=='CreateProspect' && SelectRelType=='Business '){
              	navigationURL= "/apex/Customer?rectype=Business_Prospect";
        }else if(Buttonclicked=='NewCustomer' && SelectRelType=='Individual '){
             	navigationURL= "/apex/Customer?rectype=Individual_New_Customer";
        }else if(Buttonclicked=='NewCustomer' && SelectRelType=='Business '){
            	navigationURL= "/apex/Customer?rectype=Business_New_Customer";
        }
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": navigationURL
        });
        urlEvent.fire(); 
    },
      
    /* Pradeep Dani - updated for saving the selecetd record to an attribute*/
    hidebutton :  function(component,event,helper){         
        var selectedRecBDPId = event.currentTarget.getAttribute('data-bdpId');  
        component.set("v.importObject", selectedRecBDPId);
        component.set('v.CusttypeDisabled',false);
        component.set('v.ImportDisabled',true);        
    }, 
    
    navigateToAccount: function (component, event, helper) {
        var opp = event.currentTarget;
        /*var sObectEvent = $A.get("e.force:navigateToSObject");
        sObectEvent.setParams({
            "recordId": opp.id
        });
        sObectEvent.fire();*/
        window.open('/' + opp.id); 
    }, 
    renderPage: function (component, event, helper) {
        helper.renderPage(component);
    }, 
    sortBy: function (component, event, helper) {
        var sortName = event.currentTarget.id;
        helper.sortBy(component, sortName);
    },
    /* Toshi Agarwal - DoInit method invoked on the component initialization phase*/
    doInit: function (component, event, helper){
        /* calling helper method 'SelectBussinessTypeValue' */
         helper.SelectBussinessTypeValue(component, event, helper);
    }
})