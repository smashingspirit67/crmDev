({
    
    /**
         * @Summary : Method to get the data from apex mock class .         
         * @Parameters : Component
         * @Parameters : Event         
         * @Component : CB_CustomerSearchComponent   
         * @COntroller : CB_CustomerSearchComponentController
         * @COntroller Method : Search
         * @Apex class : CB_CustomerSearchMock 
         * @Apex Method :searchCustomer        
     **/ 
    
    getSearchDetails_RelationName: function (component, event, helper, inputCmp, inputCmp1, inputCmp2, inputCmp3, toggleTarget) {        
        
        
        var parameters = [];
        parameters.push(inputCmp);
        if(inputCmp1 != null && inputCmp1 != undefined){
            parameters.push(inputCmp1);
        }         
        if(inputCmp2 != null && inputCmp2 != undefined && inputCmp3 != null && inputCmp3 != undefined){
            parameters.push(inputCmp2);
            parameters.push(inputCmp3);
        }
        component.set('v.CusttypeDisabled', true);
        var action =  component.get('c.searchCustomer');
        action.setParams({
            'customerSeqNumber' : 0,
            'parameters' : parameters                
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                $A.util.addClass(toggleTarget, 'slds-hide');
                var res = response.getReturnValue();
                if (res.length > 0) {
                    component.set("v.SearchResponse", res);
                    var records = component.get("v.SearchResponse");
                    var pageRecords = records.slice(0, 10);
                    component.set("v.pageNumber", 1);
                    component.set("v.currentList", pageRecords);
                    component.set("v.maxPage", Math.floor((res.length + 9) / 10));
                } else {
                    component.set("v.SearchResponse[0]", "empty");
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": "No results containing all your search terms were found."
                    });
                    toastEvent.fire();
                }
                console.log("res>>>"+res);
            } else{           
                $A.util.addClass(toggleTarget, 'slds-hide'); 
                console.log("failure...");
                component.set("v.SearchResponse[0]", "empty");
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "message": "No results containing all your search terms were found."
                });
                toastEvent.fire();
            }    
        });   
        $A.enqueueAction(action);
        
    },
    
    /**
         * @Summary : Method to get the data from apex mock class .         
         * @Parameters : Component
         * @Parameters : Event         
         * @Component : CB_CustomerSearchComponent   
         * @COntroller : CB_CustomerSearchComponentController
         * @COntroller Method : Search
         * @Apex class : CB_CustomerSearchMock 
         * @Apex Method :searchCustomer        
     **/     
    getSearchDetails_RelationType: function (component, event, helper, inputCmp, inputCmp1, toggleTarget) {
        
        if(inputCmp == 'Business ' && !inputCmp1.startsWith("J") && !inputCmp1.startsWith("j")){
            component.set("v.SearchResponse[0]","empty");
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": "Please enter a valid BDP Id"
            });
            toastEvent.fire();
            var toggleTarget = component.find('mySpinner');
            $A.util.addClass(toggleTarget, 'slds-hide');
        }
        else if(inputCmp == 'Individual ' && !inputCmp1.startsWith("F") && !inputCmp1.startsWith("f")){
            component.set("v.SearchResponse[0]","empty");
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": "Please enter a valid BDP Id"
            });
            toastEvent.fire();
            var toggleTarget = component.find('mySpinner');
            $A.util.addClass(toggleTarget, 'slds-hide');
        }
            else if(!inputCmp1.startsWith("F") && !inputCmp1.startsWith("f") && !inputCmp1.startsWith("J") && !inputCmp1.startsWith("j")){
                component.set("v.SearchResponse[0]","empty");
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "message": "Please enter a valid BDP Id"
                });
                toastEvent.fire();
                var toggleTarget = component.find('mySpinner');
                $A.util.addClass(toggleTarget, 'slds-hide');
            }
                else{
                    var parameters = [];         
                    
                    parameters.push(inputCmp);
                    parameters.push(inputCmp1);  
                    component.set('v.CusttypeDisabled', true);
                    var action = component.get('c.searchCustomer');  
                    action.setParams({
                        'customerSeqNumber' : 1,
                        'parameters' : parameters                
                    });
                    
                    action.setCallback(this,function(response){
                        
                        var state = response.getState();                
                        if (component.isValid() && state === "SUCCESS") { 
                            $A.util.addClass(toggleTarget, 'slds-hide');
                            var res = response.getReturnValue();
                            if (res.length > 0) {
                                component.set("v.SearchResponse", res);
                                var records = component.get("v.SearchResponse");
                                var pageRecords = records.slice(0, 10);
                                component.set("v.pageNumber", 1);
                                component.set("v.currentList", pageRecords);
                                component.set("v.maxPage", Math.floor((res.length + 9) / 10));
                            } else {
                                component.set("v.SearchResponse[0]", "empty");
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    "type": "error",
                                    "message": "No results containing all your search terms were found."
                                });
                                toastEvent.fire();
                            }
                        }else{            
                            $A.util.addClass(toggleTarget, 'slds-hide');
                            console.log("failure...");
                            component.set("v.SearchResponse[0]", "empty");
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "type": "error",
                                "message": "No results containing all your search terms were found."
                            });
                            toastEvent.fire();
                        }    
                    });   
                    $A.enqueueAction(action);
                }
        
    },
    
    
    /**
         * @Summary : Method to get the data from apex mock class .         
         * @Parameters : Component
         * @Parameters : Event         
         * @Component : CB_CustomerSearchComponent   
         * @COntroller : CB_CustomerSearchComponentController
         * @COntroller Method : Search
         * @Apex class : CB_CustomerSearchMock 
         * @Apex Method :searchCustomer        
     **/     
    getSearchDetails_DocumentType: function (component, event, helper, inputCmp3, inputCmp4, inputCmp5, toggleTarget) {        
        
        var parameters = [];         
        
        parameters.push(inputCmp3);
        parameters.push(inputCmp4);
        parameters.push(inputCmp5);
        
        component.set('v.CusttypeDisabled', true);
        var action =  component.get('c.searchCustomer');
        action.setParams({
            'customerSeqNumber' : 2,
            'parameters' : parameters                
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();                
            if (component.isValid() && state === "SUCCESS") {
                $A.util.addClass(toggleTarget, 'slds-hide');
                var res = response.getReturnValue();
                if (res.length > 0) {
                    component.set("v.SearchResponse", res);
                    var records = component.get("v.SearchResponse");
                    var pageRecords = records.slice(0, 10);
                    component.set("v.pageNumber", 1);
                    component.set("v.currentList", pageRecords);
                    component.set("v.maxPage", Math.floor((res.length + 9) / 10));
                } else {
                    component.set("v.SearchResponse[0]", "empty");
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": "No results containing all your search terms were found."
                    });
                    toastEvent.fire();
                }
                
            }else{            
                $A.util.addClass(toggleTarget, 'slds-hide');
                console.log("failure...");
                component.set("v.SearchResponse[0]", "empty");
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "message": "No results containing all your search terms were found."
                });
                toastEvent.fire();
            }    
        });   
        $A.enqueueAction(action);
        
    },
    
    
    
    /**
         * @Summary : Method to show UI according to record type.         
         * @Parameters : Component
         * @Parameters : Event         
         * @Component : CB_CustomerSearchComponent   
         * @COntroller : CB_CustomerSearchComponentController
         * @COntroller Method : Search
         * @Apex class : objectUtil
         * @Apex Method :getObjectRecordTypeId

     **/     
    SaveProspectRecord : function(component,event,recordtype) {  
        
        //This button ic clicked from prospect so it would be either cust prospect or indivitual prospect
        var recordtypevalue = 'CB ' +recordtype+ 'Prospect'; 
        
        
        var action =  component.get('c.getRecordTypeValue');
        action.setParams({
            'sobjectdetails' : 'Account',
            'recordtypename' : recordtypevalue,                                
        });
        action.setCallback(this,function(response){
            
            
            var state = response.getState();                
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();    
                
                var createAcountEvent = $A.get("e.force:createRecord");
                // alert(createAcountEvent);
                createAcountEvent.setParams({
                    "entityApiName": "Account",
                    "defaultFieldValues": {                
                    },
                    "recordTypeId" : res
                });
                createAcountEvent.fire();
                
                
            }else{            
                console.log("failure...");
            }    
        });   
        $A.enqueueAction(action);
        
    },
    
    
    
    
    /**
         * @Summary : Method to show UI according to record type.         
         * @Parameters : Component
         * @Parameters : Event         
         * @Component : CB_CustomerSearchComponent   
         * @COntroller : CB_CustomerSearchComponentController
         * @COntroller Method : Search
         * @Apex class : objectUtil
         * @Apex Method :getObjectRecordTypeId

     **/     
    SaveCustomerRecord : function(component,event,recordtype) {  
        
        //This button ic clicked from prospect so it would be either cust prospect or indivitual prospect
        var recordtypevalue = 'CB ' +recordtype+ 'Customer'; 
        
        
        var action =  component.get('c.getRecordTypeValue');
        action.setParams({
            'sobjectdetails' : 'Account',
            'recordtypename' : recordtypevalue                
        });
        action.setCallback(this,function(response){
            
            
            var state = response.getState();                
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();    
                
                
                var createAcountEvent = $A.get("e.force:createRecord");
                //alert(createAcountEvent);
                createAcountEvent.setParams({
                    "entityApiName": "Account",
                    "defaultFieldValues": {                
                    },
                    "recordTypeId" : res
                });
                createAcountEvent.fire();
                
            }else{            
                console.log("failure...");
            }    
        });   
        $A.enqueueAction(action);
        
    },
    
    SaveGroupRecord :function(component,event,recordtype){
        //This button ic clicked from prospect so it would be either cust prospect or indivitual prospect
        var recordtypevalue = 'CB ' +recordtype+ ' Customer'; 
        var action =  component.get('c.getRecordTypeValue');
        action.setParams({
            'sobjectdetails' : 'Account',
            'recordtypename' : recordtypevalue                
        });
        action.setCallback(this,function(response){
            var state = response.getState();  
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();
                var createAcountEvent = $A.get("e.force:createRecord");
                //alert(createAcountEvent);
                createAcountEvent.setParams({
                    "entityApiName": "Account",
                    "defaultFieldValues": {                
                    },
                    "recordTypeId" : res
                });
                createAcountEvent.fire();
                
            }else{
                console.log("failure...");
            }    
        });   
        $A.enqueueAction(action);    
    },
    
    SaveAccountPartnerRecord :function(component,event,recordtype){
        //This button ic clicked from prospect so it would be either cust prospect or indivitual prospect
        var recordtypevalue = 'CB ' +recordtype; 
        var action =  component.get('c.getRecordTypeValue');
        action.setParams({
            'sobjectdetails' : 'Account',
            'recordtypename' : recordtypevalue                
        });
        action.setCallback(this,function(response){
            var state = response.getState();  
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();
                var createAcountEvent = $A.get("e.force:createRecord");
                //alert(createAcountEvent);
                createAcountEvent.setParams({
                    "entityApiName": "Account",
                    "defaultFieldValues": {                
                    },
                    "recordTypeId" : res
                });
                createAcountEvent.fire();
                
            }else{
                console.log("failure...");
            }    
        });   
        $A.enqueueAction(action);    
    },
/************************************************************************
     * Added for the Upper Business Banking Account Partner Record Creation
     * Created BY : Bhaskar Mishra
     * Created Date : 25th September 2018
    /************************************************************************/
    createUBBAccountPartnerRecord :function(component,event){
        var recTypeId = $A.get("$Label.c.UBB_Account_Partner_Rec_Type_Id");
        var createAcountEvent = $A.get("e.force:createRecord");
        createAcountEvent.setParams({
            "entityApiName": "Account",
            "defaultFieldValues": {                
            },
            "recordTypeId" : recTypeId
        });
        createAcountEvent.fire();   
    },
    /*****************************************************************
     * Added for the Upper Business Banking Group Record Creation
     * Created BY : Bhaskar Mishra
     * Created Date : 25th September 2018
    /****************************************************************/
    createUBBGroupRecord :function(component,event){
        var recTypeId = $A.get("$Label.c.UBB_Group_Rec_Type_Id");
        var createAcountEvent = $A.get("e.force:createRecord");
        createAcountEvent.setParams({
            "entityApiName": "Account",
            "defaultFieldValues": {                
            },
            "recordTypeId" : recTypeId
        });
        createAcountEvent.fire();   
    },
    
    openModalWindow: function(component, event, recordtype) {
        var recTypeName = 'CB ' +recordtype+ 'Customer';
        component.set("v.recordTypeName",recTypeName);
        //for showing up the create pop up screen
        if(recTypeName == 'CB Business Customer'){
            component.set("v.isOpenModal", true);
        }
        else{
            component.set("v.isOpenModalForIndividual", true);
        }
    },
    
    closeModal: function(component, event) {
        // for Hide/Close Modal,set the relevant attribute to "Fasle"
        if(component.get("v.recordTypeName") == 'CB Business Customer'){  
            component.set("v.isOpenModal", false);
        }
        else{
            component.set("v.isOpenModalForIndividual", false);
        }
    },
    
    /* Makarand*/
    handleImportFunction : function(component,event,toggleSpinner) { 
        var bdpId = component.get("v.importObject");
        var searchRes = component.get("v.SearchResponse");
        var recType = component.get("v.selectedRecordtype");
        var busType = component.get("v.businessType");
        console.log(JSON.stringify(searchRes));
        
        var action =  component.get('c.doImport'); 
        action.setParams({
            //'bdpSearchresults' : JSON.stringify(searchRes),
            //'IsBDPImport' : 'true',
            'selectedBDPId' : bdpId,
            'selectedRecordtype' : recType
        });
        action.setCallback(this,function(response){            
            var state = response.getState();
            console.log(JSON.stringify(response));           
            if (state === "SUCCESS") {
                $A.util.addClass(toggleSpinner, 'slds-hide');
                var res = response.getReturnValue(); 
                
                if(res != null && res != undefined){
                    
                    var importResp = JSON.stringify(response.getReturnValue());
                    
                    var objResp = JSON.parse(importResp);
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "success",
                        "duration": 25000,
                        "message": "Success" 
                    });
                    toastEvent.fire();  
                    if (busType == "CommercialBanking"){
                        var navEvt = $A.get("e.force:navigateToSObject");
                        navEvt.setParams({
                            
                            "recordId": objResp.AccountID
                            
                        });
                        
                        navEvt.fire();
                    }
                    else{
                        var redirecturl = '/apex/Customer?rectype='+objResp.RecordType + '&id='+objResp.AccountID+ '&type=import'   
                        var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url": redirecturl
                        });
                        urlEvent.fire(); 
                    }
                } 
                else{
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "duration": 25000,
                        "message": "Unable to import the record" 
                    });
                    toastEvent.fire();
                }            
            }else{ 
                $A.util.addClass(toggleSpinner, 'slds-hide');
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "duration": 25000,
                    "message": "Issue" 
                });
                toastEvent.fire();
            }    
        });   
        $A.enqueueAction(action); 
    },
    
    renderPage: function (component) {
        var records = component.get("v.SearchResponse"),
            pageNumber = component.get("v.pageNumber"),
            pageRecords = records.slice((pageNumber - 1) * 10, pageNumber * 10);
        component.set("v.currentList", pageRecords);
    }, 
    sortBy: function (component, field) {
        var sortAsc = component.get("v.sortAsc"),
            sortField = component.get("v.sortField"),
            records = component.get("v.SearchResponse");
        sortAsc = sortField != field || !sortAsc;
        records.sort(function (a, b) {
            var t1 = a[field] == b[field],
                t2 = (!a[field] && b[field]) || (a[field] < b[field]);
            return t1 ? 0 : (sortAsc ? -1 : 1) * (t2 ? 1 : -1);
        });
        component.set("v.sortAsc", sortAsc);
        component.set("v.sortField", field);
        component.set("v.SearchResponse", records);
        this.renderPage(component);
    },
    /* Toshi Agarwal - To get the Bussines type of Logged In user on the basid of his profile*/
    SelectBussinessTypeValue : function(component,event,helper) {  
        
        var StateResponse;
        var action =  component.get('c.getBussinessType');
        action.setCallback(this, function(response) {
            //store response state 
            var state = response.getState();
            if (state === "SUCCESS") {  
                var StoreResponse = response.getReturnValue();
                component.set("v.Bussinessparamc",StoreResponse);
                this.SelectBusinessType(component,event,helper,StoreResponse);
            }  
        });   
        $A.enqueueAction(action);
        
        
    }, 
    /* Ritesh Shahare - Hide MainScreen and Display Search Screen*/
    SelectBusinessType :  function(component,event,helper,StateResponse){
        
        //   SelectBussinessTypeValue(component, event, helper) ;
        // 'ButtClicked' which button is clicked
        // var ButtClicked = event.getSource().getLocalId();
        // 'selectedRadio' which value  is selected
        var selectedRadio=StateResponse;
        
        // 'Commercial' finds the div with id CommercialbuttonTab
        var Commercial = component.find('CommercialbuttonTab'); 
        // 'Bussiness' finds the div with id BussinessbuttonTab
        var Bussiness = component.find('BussinessbuttonTab'); 
        // 'cmpMainBusiness' finds the div with id mainBusiness
        var cmpMainBusiness = component.find('mainBusiness');  
        // 'cmpinput0' finds the div with id input0
        var cmpinput0 = component.find('input0');
        //to hide other components
        var cmpTarget = component.find('input1');
        var cmpTarget1 = component.find('input2');
        var cmpTarget2 = component.find('input3');
        if(selectedRadio!=null){
            //input0 is shown and others are hidden
            $A.util.addClass(cmpinput0, 'changeMe'); 
            $A.util.addClass(cmpMainBusiness, 'input0'); 
            $A.util.removeClass(cmpMainBusiness, 'changeMe'); 
            if(selectedRadio == 'CB'){
                component.set('v.businessType','CommercialBanking');
                //CommercialbuttonTab enabled and BussinessbuttonTab is hidden
                $A.util.addClass(Commercial, 'changeMe'); 
                $A.util.removeClass(Bussiness, 'changeMe'); 
            }else{
                component.set('v.businessType','BusinessBanking');
                //BussinessbuttonTab enabled and CommercialbuttonTab is hidden
                $A.util.addClass(Bussiness, 'changeMe'); 
                $A.util.removeClass(Commercial, 'changeMe');
            }
        }
        else{
            
        }
        /*  if(ButtClicked=='BacktoMain'){
            //show mainBusiness,hide input 0,CommercialbuttonTab,BussinessbuttonTab
            $A.util.addClass(cmpMainBusiness, 'changeMe'); 
            $A.util.removeClass(cmpinput0, 'changeMe'); 
            $A.util.removeClass(Bussiness, 'changeMe'); 
            $A.util.removeClass(Commercial, 'changeMe'); 
            $A.util.removeClass(cmpTarget2, 'changeMe');
            $A.util.removeClass(cmpTarget1, 'changeMe');
            $A.util.removeClass(cmpTarget, 'changeMe');

        }*/
        //}
    }
})