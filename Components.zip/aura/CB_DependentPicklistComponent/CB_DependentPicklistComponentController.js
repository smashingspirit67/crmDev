/*************************************************************************************
* @Summary     : Client Side controller for the component CB_DependentPicklistComponent         
* @Parameters  : Component
* @Parameters  : Event
* @Parameters  : Helper
* @Component   : CB_DependentPicklistComponent   
* @Helper      : CB_DependentPicklistComponentHelper 
* @Apex class  : CB_PicklistFieldController        
***************************************************************************************/        

({

   /********************************************************************************************************************
         * @Summary         : Method to initialize values and load the component
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_DependentPicklistComponent  
         * @Helper Method   : fetchPicklistValues
         * @Apex class      : CB_PicklistFieldController      
     ********************************************************************************************************************/     
   doInit: function(component, event, helper) {
      //call the helper function with pass [component, Controller field and Dependent Field] Api name 
      var controllingFieldApiName = component.get("v.controllingFieldAPI");
      var dependentFieldApiName = component.get("v.dependentFieldAPI");
      helper.fetchPicklistValues(component, controllingFieldApiName, dependentFieldApiName);
   },

/********************************************************************************************************************
         * @Summary         : Method to set the values in controlling field and dependent field in case of edit
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_DependentPicklistComponent  
         * @Helper Method   : putValuesInFields
         * @Apex class      : CB_PicklistFieldController      
     ********************************************************************************************************************/     
 
   putValuesInFields: function(component, event, helper) {
      
      var args = event.getParam("arguments");
      var controllerValueKey = args.controllingFieldValue;
      var dependentValue = args.dependentFieldValue;
      if(controllerValueKey != null && controllerValueKey != undefined){
         component.find('controllingField').set("v.value",controllerValueKey);
         // get the map values   
         var Map = component.get("v.depnedentFieldMap");
    
         // check if selected value is not equal to None then call the helper function.
         // if controller field value is none then make dependent field value as none and disable field
         if (controllerValueKey != '-- None --') {
    
            // get dependent values for controller field by using map[key]. 
            var ListOfDependentFields = Map[controllerValueKey];
            helper.fetchDepValues(component, ListOfDependentFields);
    
         } 
         else {
            var defaultVal = [{
               class: "optionClass",
               label: '-- None --',
               value: '-- None --'
            }];
            component.find('dependentField').set("v.options", defaultVal);
            component.set("v.isDependentDisable", true);
         }
      }
      if(dependentValue != null && dependentValue != undefined){
         component.find('dependentField').set("v.value",dependentValue);
         component.set("v.isDependentDisable", false);
         
      }
      else{
      
         // get the map values   
         var Map = component.get("v.depnedentFieldMap");
    
         // check if selected value is not equal to None then call the helper function.
         // if controller field value is none then make dependent field value as none and disable field
         if (controllerValueKey != '-- None --') {
    
            // get dependent values for controller field by using map[key]. 
            var ListOfDependentFields = Map[controllerValueKey];
            helper.fetchDepValues(component, ListOfDependentFields);
    
         } 
         else {
            var defaultVal = [{
               class: "optionClass",
               label: '-- None --',
               value: '-- None --'
            }];
            component.find('dependentField').set("v.options", defaultVal);
            component.set("v.isDependentDisable", true);
         }
      }
   },
 
 /********************************************************************************************************************
         * @Summary         : Method to call on change the controller field
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_DependentPicklistComponent  
         * @Helper Method   : fetchDepValues
         * @Apex class      : CB_PicklistFieldController      
     ********************************************************************************************************************/     
 
   onControllerFieldChange: function(component, event, helper) {
      // get the selected value
      var controllerValueKey = event.getSource().get("v.value");
      // get the map values   
      var Map = component.get("v.depnedentFieldMap");
 
      // check if selected value is not equal to None then call the helper function.
      // if controller field value is none then make dependent field value is none and disable field
      if (controllerValueKey != '-- None --') {
 
         // get dependent values for controller field by using map[key].  
         // for i.e "India" is controllerValueKey so in the map give key Name for get map values like 
         // map['India'] = its return all dependent picklist values.
         var ListOfDependentFields = Map[controllerValueKey];
         helper.fetchDepValues(component, ListOfDependentFields);
 
      } else {
         var defaultVal = [{
            class: "optionClass",
            label: '-- None --',
            value: '-- None --'
         }];
         component.find('dependentField').set("v.options", defaultVal);
         component.set("v.isDependentDisable", true);
      }

      
      var controllingFieldApiName = component.get("v.controllingFieldAPI");
      var myEvent = component.getEvent("myPicklistComponentEvent");
      myEvent.setParams({"masterFieldApiName": controllingFieldApiName});
      myEvent.setParams({"controllingFieldValue": controllerValueKey});
      myEvent.setParams({"dependentFieldValue": '-- None --'});
      myEvent.fire();
   },
 /********************************************************************************************************************
         * @Summary         : Method to call on change tha Dependent field
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_DependentPicklistComponent  
         * @Helper Method   : N.A
         * @Apex class      : CB_PicklistFieldController      
     ********************************************************************************************************************/        
   onDependentFieldChange: function(component, event, helper) {
      var controllerValueSelected = component.find('controllingField').get("v.value");
      var dependentValueSelected = event.getSource().get("v.value");
      var controllingFieldApiName = component.get("v.controllingFieldAPI");
      var myEvent = component.getEvent("myPicklistComponentEvent");
      myEvent.setParams({"masterFieldApiName": controllingFieldApiName});
      myEvent.setParams({"controllingFieldValue": controllerValueSelected});
      myEvent.setParams({"dependentFieldValue": dependentValueSelected});
      myEvent.fire();
   }
})