({
    doInit : function(component, event, helper) {
        helper.getUserAccess(component, event);
    },
    
    save : function(component, event, helper) {
        try{
            var action = component.find("edit").get("e.recordSave").fire();
        }
        catch(e){
            alert("error occured");
            var toggleTarget = component.find('mySpinner');
        	$A.util.addClass(toggleTarget, 'slds-hide');
        }
    },
    
    showSpinner : function(component, event, helper) {
        var toggleTarget = component.find('mySpinner');
        $A.util.removeClass(toggleTarget, 'slds-hide');
    },
    
    handleDoneWaiting : function(component, event, helper) {
        var toggleTarget = component.find('mySpinner');
        $A.util.addClass(toggleTarget, 'slds-hide');
    },
    
    handleSaveSuccess : function(component, event, helper) {
        var toggleTarget = component.find('mySpinner');
        $A.util.addClass(toggleTarget, 'slds-hide');
        $A.get("e.force:closeQuickAction").fire();
        var toastEvent = $A.get("e.force:showToast");
    	toastEvent.setParams({
        "title": "Success!",
        "type": "success",
        "message": "The record has been updated successfully."
    	});
    	toastEvent.fire();
        $A.get('e.force:refreshView').fire();
    },
    
    cancel : function(component, event, helper) {
		$A.get("e.force:closeQuickAction").fire();
	},
})