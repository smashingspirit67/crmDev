({
	/********************************************************************************************************************
         * @Summary         : Method to set the value for isSystemAdmin attribute of the component on load of the component      
         * @Parameters      : Component
         * @Parameters      : Event
         * @Component       : CB_EditRelationshipComponent 
         * @Helper Method   : getUserAccess
         * @Apex class      : CB_EditRecordController 
         * @Apex Method     : getAccessOfLoggedInUser       
     ********************************************************************************************************************/     
  
    getUserAccess : function(component, event) {

        var action = component.get('c.getAccessOfLoggedInUser');
        //sending parameters to the apex method
        action.setParams({
            "recId" : component.get('v.recordId')
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                var UserHasAccess = actionResult.getReturnValue();
                if(UserHasAccess){
                    this.loadComponentData(component, event);
                }
                else{
                    $A.get("e.force:closeQuickAction").fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                    "title": "Insufficient Privileges!",
                    "type": "error",
                    "message": "You do not have sufficient privileges to edit this record"
                    });
                    toastEvent.fire();
                }
            }
        });
        $A.enqueueAction(action);     
    },
    
    loadComponentData : function(component, event, helper) {
       	var action = component.get('c.getAccountRecord');
        action.setParams({
            "recId": component.get("v.recordId")
        });
        action.setCallback(this, function(a){ 
            var returnedRecord = a.getReturnValue();
            component.set('v.relationship',returnedRecord);
            
            var toggleTarget = component.find('mySpinner');
            $A.util.addClass(toggleTarget, 'slds-hide');
        });
        $A.enqueueAction(action);
    },
})