({
	doInit: function (component, event, helper) {
		component.set('{!v.counter360}', false);
	},

	onRender: function (component, event, helper) {
		if (!component.get('{!v.counter360}')) {
			var userId = '';
            userId = component.get("v.recordId");
            if(userId!=null){
			
			helper.mapHelper(component, event, helper, userId, '{!c.setStuckyMap}', '{!v.stuckyList}', '{!v.stuckyMap}');
			helper.mapHelper(component, event, helper, userId, '{!c.setLoanMap}', '{!v.loanList}', '{!v.loanMap}');
			helper.mapHelper(component, event, helper, userId, '{!c.setDepositMap}', '{!v.depositList}', '{!v.depositMap}');
			helper.mapHelper(component, event, helper, userId, '{!c.setCashMgmtMap}', '{!v.cashMgmtList}', '{!v.cashMgmtMap}');
			helper.mapHelper(component, event, helper, userId, '{!c.setCardMap}', '{!v.cardsList}', '{!v.cardsMap}');
			helper.mapHelper(component, event, helper, userId, '{!c.setOtherMap}', '{!v.otherList}', '{!v.otherMap}');
			helper.mapHelper(component, event, helper, userId, '{!c.setClosedMap}', '{!v.closedList}', '{!v.closedMap}');
            }
			function sumHelper(component, event, helper) {
				helper.sumTopCards(component, event, helper);
			}

			setTimeout(sumHelper.bind(null, component, event, helper), 3000);

			console.log('Ran ' + component.get('{!v.counter360}'));
			component.set('{!v.counter360}', true);
			console.log('Ran ' + component.get('{!v.counter360}'));
		}
	},

	navToRecord: function (component, event, helper) {
		var url = event.currentTarget.id;
		var navEvt = $A.get("e.force:navigateToSObject");
		navEvt.setParams({
			"recordId": url
		});
		navEvt.fire();
	},

	toggleAccordion: function (component, event, helper) {
		// var targetId = event.currentTarget.id.split(';')[0];
		var targetIndex = event.currentTarget.id;
		var icon = component.find('chevron');
		if (icon.length) {
			if (icon[targetIndex].get('v.iconName') == 'utility:chevronright') {
				icon[targetIndex].set('v.iconName', 'utility:chevrondown');
			} else {
				icon[targetIndex].set('v.iconName', 'utility:chevronright');
			}
		} else {
			if (icon.get('v.iconName') == 'utility:chevronright') {
				icon.set('v.iconName', 'utility:chevrondown');
			} else {
				icon.set('v.iconName', 'utility:chevronright');
			}
		}
		$A.util.toggleClass(document.getElementById(targetIndex + ';sub'), 'slds-hide');
		console.log('Toggled');
	},

	display: function (component, event, helper) {
		helper.toggleHelper(component, event);
	},

	displayOut: function (component, event, helper) {
		helper.toggleHelper(component, event);
	}
})