({
	arrSum: function (component, arr, keyList, setMap) {
		var keyMap = new Map();

		for (var i = 0; i < arr.length; i++) {
			for (var j = 0; j < keyList.length; j++) {
				if (arr[i][keyList[j]] != null) {
					if (keyMap[keyList[j]] != null) {
						keyMap[keyList[j]] += parseFloat(arr[i][keyList[j]]);
					} else {
						keyMap[keyList[j]] = arr[i][keyList[j]];
					}
				}
			}
		}
		component.set(setMap, keyMap);
	},

	sumTopCards: function (component, event, helper) {
		var cardsRevYTD = component.get('{!v.cardsMap.CB_Transaction_Revenue_YTD}');
		var otherYTDFees = component.get('{!v.otherMap.CB_YTD_Fees}');
		var loanNII = component.get('{!v.loanMap.CB_Net_Interest_Income_YTD}');
		var loanFees = component.get('{!v.loanMap.CB_Total_Loan_Fees_YTD}');
		var depositsNII = component.get('{!v.depositMap.CB_Net_Interest_Income_YTD}');
		var cashMgmtFees = component.get('{!v.cashMgmtMap.CB_Fees_Due_YTD}');
		var loanExposure = component.get('{!v.loanMap.CCMIS_Exposure_Amount}');
		var depositBalance = component.get('{!v.depositMap.CB_Month_End_Balance}');
		var cashMgmtPxV = component.get('{!v.cashMgmtMap.CB_PxV_YTD}');
		cardsRevYTD = helper.nAnChecker(component, event, helper, cardsRevYTD);
		otherYTDFees = helper.nAnChecker(component, event, helper, otherYTDFees);
		loanNII = helper.nAnChecker(component, event, helper, loanNII);
		loanFees = helper.nAnChecker(component, event, helper, loanFees);
		depositsNII = helper.nAnChecker(component, event, helper, depositsNII);
		cashMgmtFees = helper.nAnChecker(component, event, helper, cashMgmtFees);
		loanExposure = helper.nAnChecker(component, event, helper, loanExposure);
		depositBalance = helper.nAnChecker(component, event, helper, depositBalance);
		cashMgmtPxV = helper.nAnChecker(component, event, helper, cashMgmtPxV);

		var card4 = [];
		var card5 = [];

		card4.push(cardsRevYTD, otherYTDFees);
		card5.push(loanNII, loanFees, depositsNII, cashMgmtFees, cardsRevYTD, otherYTDFees);

		function isComplete(array) {
			var newArr = [];
			for (var i = 0; i < array.length; i++) {
				if (array[i] != null && array[i] != null && !isNaN(array[i])) {
					newArr.push(array[i]);
				}
			}
			return newArr;
		}

		var actualCard4 = isComplete(card4);
		var actualCard5 = isComplete(card5);
		actualCard4 = actualCard4.reduce((a, b) => a + b, 0);
		actualCard5 = actualCard5.reduce((a, b) => a + b, 0);

		loanExposure = '$' + Math.round(loanExposure / 1000000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' MM';
		depositBalance = '$' + Math.round(depositBalance / 1000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' M';
		cashMgmtPxV = '$' + Math.round(cashMgmtPxV / 1000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' M';
		actualCard4 = '$' + Math.round(actualCard4 / 1000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' M';
		actualCard5 = '$' + Math.round(actualCard5 / 1000).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' M';

		component.set('{!v.graphValue1}', loanExposure);
		component.set('{!v.graphValue2}', depositBalance);
		component.set('{!v.graphValue3}', cashMgmtPxV);
		component.set('{!v.graphValue4}', actualCard4);
		component.set('{!v.graphValue5}', actualCard5);
	},

	nAnChecker: function (component, event, helper, number) {
		if (!isNaN(number) && number!=null && number != '' && number != undefined) {
			return number;
		} else {
			return 0;
		}
	},

	mapHelper: function (component, event, helper, param, controllerClass, setAttribute, setMap) {
		var action = component.get(controllerClass);
		action.setParams(
			{
				"param": param
			}
		);

		action.setCallback(this, function (response) {
			var state = response.getState();
			if (state === 'SUCCESS') {
				var keys = Object.keys(response.getReturnValue())
				var majorKeys = [];
				var arr = [];
				for(var i = 0; i < keys.length; i++) {
					var map = {};
					var items = response.getReturnValue()[keys[i]];
					var indexCount = 0;
					var lengthCount = 0
					 for (var j = 0; j < items.length; j++) {
						 if(lengthCount < Object.keys(items[j]).length) {
							 lengthCount = Object.keys(items[j]).length;
							 indexCount = j;
						 }
					 }
					var secondKeys = Object.keys(items[indexCount])
					majorKeys = secondKeys;
					for (var l = 0; l < items.length; l++) {
						for(var k = 0; k < secondKeys.length; k++) {
							if(l == 0) {
								if (helper.numChecker(component, event, helper, items[l][secondKeys[k]])) {
									map[secondKeys[k]] = parseFloat(helper.nAnChecker(component, event, helper, items[l][secondKeys[k]]));
								} else if (items[l][secondKeys[k]] == null){
									map[secondKeys[k]] = helper.nAnChecker(component, event, helper, items[l][secondKeys[k]]);
								} else {
									map[secondKeys[k]] = items[l][secondKeys[k]];
								}
							} else {
								if (helper.numChecker(component, event, helper, items[l][secondKeys[k]])) {
									map[secondKeys[k]] += parseFloat(items[l][secondKeys[k]]);
								}
							}
						}
					}
					arr.push(map);
				}
                if(arr[0]!= null && arr[0].parentLevel != null && arr[0].parentLevel != undefined){
                    if (arr[0].parentLevel != 'Ultimate Top Parent') {
                        // Set specific component
                        component.set(setAttribute, arr);
                        console.table(arr);
                        helper.arrSum(component, arr, majorKeys, setMap);
                    } else if (arr[0].parentLevel == 'Ultimate Top Parent') {
                        helper.groupOfGroupSum(component, event, helper, arr, majorKeys, setAttribute, setMap);
                    }
                }
			}
		});
		$A.enqueueAction(action);
	},

	groupOfGroupSum: function(component, event, helper, arr, majorKeys, setAttribute, setMap) {
		function onlyUnique(value, index, self) {
			return self.indexOf(value) === index;
		}
		var idArr = [];

		for(var i = 0; i < arr.length; i++){
			idArr.push(arr[i].parentId)
		}
		
		var uniqueIds = idArr.filter(onlyUnique);
		var newArr = [];

		for (var j = 0; j < uniqueIds.length; j++) {
			var newMap = {};
			for(var l = 0; l < arr.length; l++){
				// debugger;
				for (var k = 0; k < majorKeys.length; k++) {
					if(uniqueIds[j] == arr[l].parentId) {
						if (newMap[majorKeys[k]] == null) {
							if (helper.numChecker(component, event, helper, arr[l][majorKeys[k]])) {
								newMap[majorKeys[k]] = helper.nAnChecker(component, event, helper, arr[l][majorKeys[k]]);
							} else if (arr[l][majorKeys[k]] == null) {
								newMap[majorKeys[k]] = helper.nAnChecker(component, event, helper, arr[l][majorKeys[k]]);
							} else {
								newMap[majorKeys[k]] = arr[l][majorKeys[k]];
							}
						} else {
							if (helper.numChecker(component, event, helper, arr[l][majorKeys[k]])) {
								newMap[majorKeys[k]] += parseFloat(arr[l][majorKeys[k]]);
							}
						}
					}
				}
			}
			newArr.push(newMap);
		}
		component.set(setAttribute, newArr);
		component.set('{!v.groupTruth}', false);
		helper.arrSum(component, newArr, majorKeys, setMap)
	},

	numChecker: function(component, event, helper, number) {
		return !isNaN(parseFloat(number)) && isFinite(number);
	},

	toggleHelper: function (component, event) {
		var toggleText = component.find("tooltip");
		$A.util.toggleClass(toggleText, "slds-hide");
	}
})