({

    /********************************************************************************************************************
         * @Summary         : Method to set the value for attributes of the component on load of the component      
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_OwnerChangeComponent 
         * @Helper Method   : getRelationship
         * @Apex class      : CB_OwnerChangeController      
     ********************************************************************************************************************/     
   
    doInit : function(component, event, helper) {
        helper.checkAccessOfUser(component, event);
        helper.getRelationship(component, event);
    },
    
    /********************************************************************************************************************
         * @Summary         : Method to handle save of edited relationship fields      
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_OwnerChangeComponent 
         * @Helper Method   : saveRecord, createLogRecord
         * @Apex class      : CB_OwnerChangeController        
     ********************************************************************************************************************/     
   
    handleSaveRecord: function(component, event, helper) {
        helper.saveRecord(component, event);
    },
      
    /********************************************************************************************************************
         * @Summary         : Method to close the quick action      
         * @Parameters      : Component
         * @Parameters      : Event
         * @Parameters      : Helper
         * @Component       : CB_OwnerChangeComponent 
         * @Helper Method   : NA
         * @Apex class      : CB_OwnerChangeController        
     ********************************************************************************************************************/     
     
    closeComponent: function(component, event, helper) {
    	var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
    },

})