({
    /********************************************************************************************************************
         * @Summary 		: Method to check that the request is raised by a valid user who has edit access to the record     
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_OwnerChangeComponent 
         * @Helper Method 	: checkAccessOfUser
         * @Apex class 		: CB_OwnerChangeController 
         * @Apex Method 	: getAccessOfLoggedInUser        
     ********************************************************************************************************************/     

    checkAccessOfUser : function(component, event) {
        // calling apex method
        var action = component.get('c.getAccessOfLoggedInUser');
        //sending parameters to the apex method
        action.setParams({
            "recId": component.get("v.recordId")
        });
        
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                var userHasEditAccess = actionResult.getReturnValue();
                if(!userHasEditAccess){
                    var toastEvent = $A.get("e.force:showToast");
            		toastEvent.setParams({
                       "title": "Insufficient Privilege",
                       "type": "error",
                	   "mode": "sticky",
                       "message": "You do not have sufficient privileges to edit this record."
                        });
            		toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }
                else{
                    this.checkRequestingUser(component, event);
                }
            }
            });
        $A.enqueueAction(action);	
    },
    
    /********************************************************************************************************************
         * @Summary 		: Method to check that the request is raised by a valid user      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_OwnerChangeComponent 
         * @Helper Method 	: checkRequestingUser
         * @Apex class 		: CB_OwnerChangeController 
         * @Apex Method 	: getLoggedInUserRole        
     ********************************************************************************************************************/     

    checkRequestingUser : function(component, event) {
        // calling apex method
        var action = component.get('c.getLoggedInUserRole');
        //sending parameters to the apex method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                var validityOfUser = actionResult.getReturnValue();
                if(validityOfUser.includes('Invalid User')){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "title": "Invalid User",
                        "message": "Only Relationship Owner OR their Senior RA OR Manager or RA can raise this request"
                    });
                    toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }
            }
            });
        $A.enqueueAction(action);	
    },
    /********************************************************************************************************************
         * @Summary 		: Method to set the value for relationship attribute of the component on load of the component      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_OwnerChangeComponent 
         * @Helper Method 	: getRelationship
         * @Apex class 		: CB_OwnerChangeController 
         * @Apex Method 	: getRelationship        
     ********************************************************************************************************************/     
    
    getRelationship : function(component, event) {
        // calling apex method to fetch relationship record
        var action = component.get('c.getRelationship');
        //sending parameters to the apex method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                var accountReturned = actionResult.getReturnValue();
                //checking if the request was raised already
                if(accountReturned.CB_RequestedNewOwner__c!= null){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "info",
                        "title": "Information!",
                        "message": "Already an Owner Change request has been raised for this Relationship.New Owner Requested - "+accountReturned.CB_RequestedNewOwner__c
                    });
                    toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }
                else{
                    component.set('v.relationship', accountReturned);
                }
            }
        });
        $A.enqueueAction(action);	 
    },

    
    /********************************************************************************************************************
         * @Summary 		: Method to save the edited values of the relationship record      
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_OwnerChangeComponent  
         * @Helper Method 	: saveRecord
         * @Apex class 		: CB_OwnerChangeController 
         * @Apex Method 	: UpdateRelationship        
     ********************************************************************************************************************/     
    
    saveRecord : function(component, event) {
        
        component.set("v.errorMessage", null);
        var selectedUser = component.get("v.selectedLookUpRecord").Name;
        var reasonForReassign = component.find("reason").get("v.value");
        if(selectedUser == null || !(reasonForReassign) ){
            var errMessage = "These required fields must be completed: New Owner, Reason for Reassignment.";
            component.set("v.errorMessage", errMessage);
        }
        else{
            // calling apex method to update relationship record
            var action = component.get('c.UpdateRelationship');
            
            var relationshipRecord = component.get("v.relationship");
            component.set("v.relationship.CB_Reason_for_Reassignment__c",reasonForReassign);
            component.set("v.relationship.CB_RequestedNewOwner__c",selectedUser);
            
            //sending parameters to the apex method
            action.setParams({
                "acc" : relationshipRecord
            });
            
            
            action.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === "SUCCESS") {
                    var message = actionResult.getReturnValue();
                    if(message != null){
                    	var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                           "title": "Error",
                           "type": "error",
                           "mode": "sticky",
                           "message": message
                            });
            			toastEvent.fire();
                    }
                    else{
                        this.createLogRecord(component, event);
                    }
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                } else if (state === "INCOMPLETE") {
                    console.log("User is offline, device doesn't support drafts.");
                } else if (state === "ERROR") {
                    console.log('Problem saving record, error: ' + JSON.stringify(actionResult.getError()));
                } else {
                    console.log('Unknown problem, state: ' + actionResult.getState() + ', error: ' + JSON.stringify(actionResult.getError()));
                }
            });
            $A.enqueueAction(action);
        }
        
    },
    
    /********************************************************************************************************************
         * @Summary 		: Method to record in the Owner Change Log object
         * @Parameters 		: Component
         * @Parameters 		: Event
         * @Component 		: CB_OwnerChangeComponent  
         * @Helper Method 	: createLogRecord
         * @Apex class 		: CB_OwnerChangeController 
         * @Apex Method 	: createOwnerChangeLog    
     ********************************************************************************************************************/     
    createLogRecord: function(component, event) {
        
        //Fetching the values for sending to the server side controller
        var selectedUser = component.get("v.selectedLookUpRecord").Id;
        var reasonForReassign = component.find("reason").get("v.value");
        var relationshipRecord = component.get("v.relationship");
        
        if(selectedUser && reasonForReassign){
            
            // calling apex method to create Log record
            var action = component.get('c.createOwnerChangeLog');
            
            //sending parameters to the apex method
            action.setParams({
                "acc" : relationshipRecord,
                "newOwner" : selectedUser,
                "reason" : reasonForReassign
            });
            
            action.setCallback(this, function(actionResult) {
                var state = actionResult.getState();
                if (state === "SUCCESS") {
                    console.log("Record Created Succesfully.");
                } else if (state === "INCOMPLETE") {
                    console.log("User is offline, device doesn't support drafts.");
                } else if (state === "ERROR") {
                    console.log('Problem saving record, error: ' + JSON.stringify(actionResult.getError()));
                } else {
                    console.log('Unknown problem, state: ' + actionResult.getState() + ', error: ' + JSON.stringify(actionResult.getError()));
                }
            });
            $A.enqueueAction(action);
        }
        
    }
    
})