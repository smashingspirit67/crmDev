({
	doInit : function(component, event, helper) {
        helper.handleAccessToTheRecord(component, event);
	}
})