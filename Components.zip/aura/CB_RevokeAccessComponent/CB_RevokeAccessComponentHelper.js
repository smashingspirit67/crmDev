({
	handleAccessToTheRecord : function(component, event) {
		// calling apex method
        var action = component.get('c.checkAccessOfTheCurrentUser');
        //sending parameters to the apex method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                var returnedMap = actionResult.getReturnValue();
                for(var key in returnedMap){
                    if(returnedMap[key].includes('Invalid User')){
                    var toastEvent = $A.get("e.force:showToast");
            		toastEvent.setParams({
                       "title": "Insufficient Privileges",
                       "type" : "error",
                	   "mode" : "sticky",
                       "message": "You do not have sufficient privileges to access this record."
                    });
            		toastEvent.fire();
                    var homeEvent = $A.get("e.force:navigateToObjectHome");
                    homeEvent.setParams({
                        "scope": key
                    });
                    homeEvent.fire();
                	}
                }
            }
        });
        $A.enqueueAction(action);	
    }
})