/*
 * @Name : RefreshAccountController.js
 * @Author : Baidyanath Sinha
 * @Date : 02/25/2018
 * @Component : RefreshAccount.cmp  
 * @Helper Method : AccountRefresh
 * @Apex controller : CB_AccountController 
 * Modification Log: 
 * Developer                Date                   Modification ID      Description
 * Baidyanath             02/25/2018                  1                Initial version
 */
({
	doInit : function(component, event, helper) {
		helper.AccountRefresh(component,event);
	}
})