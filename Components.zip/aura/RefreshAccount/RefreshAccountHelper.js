/*
 * @Name : RefreshAccountHelper.js
 * @Author : Baidyanath Sinha
 * @Date : 02/25/2018
 * @Component : RefreshAccount.cmp
 * @Apex controller : CB_AccountController 
 * @Apex method : refreshCustomerRecord 
 * Modification Log: 
 * Developer                Date                   Modification ID      Description
 * Baidyanath             02/25/2018                  1                Initial version
 */
({
	AccountRefresh : function(component,event) {
        
	  var action =  component.get('c.refreshCustomerRecord');
       action.setParams({
                 'recId' : component.get("v.recordId")               
       });	
		   action.setCallback(this,function(response){
		   	 var state = response.getState();

		   	 if(state == 'SUCCESS'){
               
                $A.get("e.force:closeQuickAction").fire();
                var resMsg = response.getReturnValue();
                 if(resMsg.includes('Invalid User')){
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "type":"error",
                            "mode":"sticky",
                            "message": "You don’t have sufficient privilege to refresh  the Relationship."
                        });
                        toastEvent.fire(); 
                 }   
                 else if(resMsg.includes('Refresh Success')){
                     var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "type":"success",
                            "title": "Success!",
                            "message": "The record has been refreshed."
                        });
                        toastEvent.fire();
                     $A.get('e.force:refreshView').fire();
                     
                 }
                 else if(resMsg.includes('Error 500')){
                     
                     $A.get("e.force:closeQuickAction").fire();
                     var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "type":"error",
                            "message": "Error while calling BDP service."
                        });
                        toastEvent.fire();
                 }
              }else{
                  alert("Refresh4");
		   	 	console.log('failure');
		   	 }
		   });

		  $A.enqueueAction(action); 

    },
})