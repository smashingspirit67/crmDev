({
	

	rootNodeClicked: function(component, event, helper) {
		console.log('Root Node Cicked', event);
		console.log("Node is ", event.getParam('node'));
        
        var x = JSON.stringify(event.getParam('node'));
        var y = JSON.parse(x);
        var name = y.text;
		if(name=='Child1')
        {
            component.set("v.loanTableData",'true');
        }
        else if(name=='Child2')
        {
            component.set("v.DepositTableData",'true');
        }
        else if(name=='Parent')
        {
            component.set("v.CashTableData",'true');
        }
	},

	leftIconClicked: function(component, event, helper) {
		console.log('Left Icon Cicked', event);
		console.log("Node is ", event.getParam('node'));
        component.set("v.loanTableData",'12345');	
	},

	righticonclicked: function(component, event, helper) {
		console.log('Right Icon Cicked', event);
		console.log("Node is ", event.getParam('node'));
        component.set("v.loanTableData",'12345');	
	},

	nodeClicked: function(component, event, helper) {
		console.log('Node Cicked>>>>>>>>>', event);
		console.log("Node is ", event.getParam('node'));
		// reset hierarchy data here... (may be call an api)
		
		alert('Node clicked');
		
		var sc = event.getSource();
		try{
			var evt = sc.getEvent('rebuildhierarchy');
			evt.fire();
			//console.log('Event triggered successfully', evt);
		}catch(e){
			//console.log('Exception is ', e);
		}
			
	},

    
    doInit:function(component,event,helper){
       //helper.callApexMethod(component,event,helper)
		//component.set("v.hData",JSON.stringify(helper.getData()));	
		var accntId =component.get("v.recordId");
        var baseUrl = component.get("c.fetchBaseURL");
        baseUrl.setCallback(this, function(a){ 
            var urlOfOrg = a.getReturnValue();
        	var url = urlOfOrg+'/apex/CB_AccountOrg?accntId='+accntId;
        	component.set("v.frameSrc",url);
        });
        $A.enqueueAction(baseUrl);
        
	}
    
})