({
	getData: function() {
		var hData = {
			   "rootNode":{
			   				"id":"0010I00001b5QNU"
			   			  },
			   "nodes":[
			      {
			         "type":"text",
			         "text":"Parent",
			         "rootNodeClick":null,
			         "rightIconClick":null,
			         "parentid":"0010I00001b5QOS",
			         "leftIconClick":null,
			         "imageURL":null,
			         "id":"0010I00001b5QNU",
			         "description":"Parent Node",
			         "data":null
			      },
			      {
			         "type":"text",
			         "text":"Child1",
			         "rootNodeClick":null,
			         "rightIconClick":null,
			         "parentid":"0010I00001b5QNU",
			         "leftIconClick":null,
			         "imageURL":null,
			         "id":"0010I00001b5QNe",
			         "description":"Child1",
			         "data":null
			      },
			      {
			         "type":"text",
			         "text":"Child2",
			         "rootNodeClick":null,
			         "rightIconClick":null,
			         "parentid":"0010I00001b5QNU",
			         "leftIconClick":null,
			         "imageURL":null,
			         "id":"0010I00001b5QNt",
			         "description":"Child2",
			         "data":null
			      }
			   ]
		}
		
        return hData;	
	},

     callApexMethod : function (component,event){    
        var accntId = component.get("v.recordId");
        var action = component.get("c.getRelationshipHierarchyData");    
        action.setParams({"accntId" : accntId}); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state=='SUCCESS' && response != null){
                component.set("v.hData",response.getReturnValue());	
            }
        });
         
        $A.enqueueAction(action); 
    },

})