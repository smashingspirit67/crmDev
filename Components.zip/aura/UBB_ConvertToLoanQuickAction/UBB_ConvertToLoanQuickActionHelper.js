({
    getDeal : function(component, event){
		// calling apex method to fetch child record
        var action = component.get('c.getOpportunityRecord');
        //sending parameters to the apex method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        action.setCallback(this, function(actionResult) {
            var state = actionResult.getState();
            if (state === 'SUCCESS') {
                component.set('v.Deal', actionResult.getReturnValue());
                var dealRecord = component.get('v.Deal');
                if(dealRecord.LLC_BI__Loan__c != null && dealRecord.LLC_BI__Loan__c != undefined){
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "type": "error",
                            "mode":"sticky",
                            "message": "This Deal already has a loan."
                        });
                    toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }
                else{
                    
                    console.log("/apex/LLC_BI__LifeCycleConverter?id="+dealRecord.Id+"&RelationshipAPIName="+dealRecord.AccountId+
                        "&accountAPIName="+dealRecord.AccountId+"&productApiName="+dealRecord.LLC_BI__Product__c+
                        "&productTypeApiName="+dealRecord.LLC_BI__Product_Type__c+"&productLineApiName="+dealRecord.LLC_BI__Product_Line__c+
                        "&convertedDateAPIName="+dealRecord.LLC_BI__Converted_Date__c+"&setDestinationFieldHidden=true&convertedProductName="+dealRecord.Name+
                        "&createBusinessEntity=false&mergeAccountIdApiName="+dealRecord.AccountId);
                    
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                      "url": '/apex/LLC_BI__LifeCycleConverter?id='+dealRecord.Id+'&RelationshipAPIName='+dealRecord.AccountId+'&accountAPIName='+dealRecord.AccountId+'&productApiName='+dealRecord.LLC_BI__Product__c+'&productTypeApiName='+dealRecord.LLC_BI__Product_Type__c+'&productLineApiName='+dealRecord.LLC_BI__Product_Line__c+'&convertedDateAPIName='+dealRecord.LLC_BI__Converted_Date__c+'&setDestinationFieldHidden=true&convertedProductName='+dealRecord.Name+'&createBusinessEntity=false&mergeAccountIdApiName='+dealRecord.AccountId,
                      "isredirect": "true"
                    });
                    urlEvent.fire();
                    
                    $A.get("e.force:closeQuickAction").fire();
                    
              }
           }
        });
        $A.enqueueAction(action);
	}
})